##  Dummy Variables & One Hot Encoding


```python
import pandas as pd
import numpy as np

```


```python
d = pd.read_csv('https://raw.githubusercontent.com/codebasics/py/master/ML/5_one_hot_encoding/Exercise/carprices.csv')
```


```python
d = d.rename({'Sell Price($)': 'Price', 'Car Model':'car_model'}, axis=1)
```


```python
d.head()
```


```python
# get_dummy variables
d1 = pd.get_dummies(d.car_model)
```


```python
d = pd.concat([d,d1], axis='columns')
```


```python
d.head()
```


```python
d = d.rename({'Audi A5':'Audi','BMW X5':'BMW','Mercedez Benz C class':'Mercedes'}, axis=1)
```


```python
d.head()
```


```python
d = d.drop(['car_model','Mercedes'], axis=1)
```


```python
d.head()

```


```python
X = d.drop(['Price'], axis=1)
```


```python
X.head()
```


```python
y = d.Price
```


```python
y.head()
```


```python
from sklearn.linear_model import LinearRegression
```


```python
model = LinearRegression()
```


```python
model.fit(X,y)
```


```python
model.predict([[35000,3,0,0]])
```


```python
model.score(X,y)
```


```python
# One_Hot_Encoding
from sklearn.preprocessing import LabelEncoder
```


```python
d = pd.read_csv("https://raw.githubusercontent.com/codebasics/py/master/ML/5_one_hot_encoding/Exercise/carprices.csv")
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car Model</th>
      <th>Mileage</th>
      <th>Sell Price($)</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW X5</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW X5</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW X5</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW X5</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW X5</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
d = d.rename({'Sell Price($)': 'Price', 'Car Model':'car_model'}, axis=1)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_model</th>
      <th>Mileage</th>
      <th>Price</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW X5</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW X5</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW X5</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW X5</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW X5</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
le = LabelEncoder()
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_model</th>
      <th>Mileage</th>
      <th>Price</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW X5</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW X5</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW X5</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW X5</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW X5</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1 = d
```


```python
d1.car_model = le.fit_transform(d1.car_model)
```


```python
d1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_model</th>
      <th>Mileage</th>
      <th>Price</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
      <td>59000</td>
      <td>29400</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0</td>
      <td>52000</td>
      <td>32000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0</td>
      <td>72000</td>
      <td>19300</td>
      <td>6</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0</td>
      <td>91000</td>
      <td>12000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2</td>
      <td>67000</td>
      <td>22000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2</td>
      <td>83000</td>
      <td>20000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2</td>
      <td>79000</td>
      <td>21000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>59000</td>
      <td>33000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = d1.drop(['Price'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_model</th>
      <th>Mileage</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>69000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>35000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>57000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>22500</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>46000</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d1.Price
```


```python
y.head()
```




    0    18000
    1    34000
    2    26100
    3    40000
    4    31500
    Name: Price, dtype: int64




```python
from sklearn.linear_model import LinearRegression
```


```python
model = LinearRegression()
```


```python
model.fit(X,y)
```




    LinearRegression()




```python
model.predict([[1,69000,6]])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
      warnings.warn(
    




    array([22855.47176747])




```python
model.score(X,y)
```




    0.8719970367825953



---

## Training and Testing Data


```python
import pandas as pd
import numpy as np
```


```python

```


```python
d = pd.read_csv("https://raw.githubusercontent.com/codebasics/py/master/ML/5_one_hot_encoding/Exercise/carprices.csv")
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car Model</th>
      <th>Mileage</th>
      <th>Sell Price($)</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW X5</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW X5</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW X5</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW X5</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW X5</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
d=d.rename({'Car Model':'car_model','Sell Price($)':'price'},axis=1)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_model</th>
      <th>Mileage</th>
      <th>price</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW X5</td>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW X5</td>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW X5</td>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW X5</td>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW X5</td>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
d=d.drop(['car_model'], axis=1)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mileage</th>
      <th>price</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>69000</td>
      <td>18000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>35000</td>
      <td>34000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>57000</td>
      <td>26100</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>22500</td>
      <td>40000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>46000</td>
      <td>31500</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
%matplotlib inline
plt.scatter(d['Mileage'],d['price'])
```




    <matplotlib.collections.PathCollection at 0x1a76f63b700>




    
![png](output_51_1.png)
    



```python
plt.scatter(d['Age(yrs)'], d['price'])
```




    <matplotlib.collections.PathCollection at 0x1a77a8918a0>




    
![png](output_52_1.png)
    



```python
X = d[['Mileage','Age(yrs)']]
y = d[['price']]
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=10)
```


```python
len(X_train)
```




    10




```python
len(d)
```




    13




```python
len(X_test)
```




    3




```python
X_train   # random sampling
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mileage</th>
      <th>Age(yrs)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>52000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>8</th>
      <td>91000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>57000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>12</th>
      <td>59000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>59000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>10</th>
      <td>83000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>35000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>0</th>
      <td>69000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>46000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>9</th>
      <td>67000</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.linear_model import LinearRegression
```


```python
model = LinearRegression()
```


```python
model.fit(X_train, y_train)
```




    LinearRegression()




```python
y_pred=model.predict(X_test)
```


```python
y_test
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>40000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>19300</td>
    </tr>
    <tr>
      <th>11</th>
      <td>21000</td>
    </tr>
  </tbody>
</table>
</div>




```python
model.score(X_test, y_test)
```




    0.9224816911971743



---

## Logistic Regression



```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
```


```python
d = pd.read_csv("C:/Users/Gulfam/Downloads/df.csv")
```


```python
d.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>last_evaluation</th>
      <th>number_project</th>
      <th>average_montly_hours</th>
      <th>time_spend_company</th>
      <th>Work_accident</th>
      <th>left</th>
      <th>promotion_last_5years</th>
      <th>Department</th>
      <th>salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.38</td>
      <td>0.53</td>
      <td>2</td>
      <td>157</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.80</td>
      <td>0.86</td>
      <td>5</td>
      <td>262</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.11</td>
      <td>0.88</td>
      <td>7</td>
      <td>272</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.72</td>
      <td>0.87</td>
      <td>5</td>
      <td>223</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.37</td>
      <td>0.52</td>
      <td>2</td>
      <td>159</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.41</td>
      <td>0.50</td>
      <td>2</td>
      <td>153</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.10</td>
      <td>0.77</td>
      <td>6</td>
      <td>247</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.92</td>
      <td>0.85</td>
      <td>5</td>
      <td>259</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.89</td>
      <td>1.00</td>
      <td>5</td>
      <td>224</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.42</td>
      <td>0.53</td>
      <td>2</td>
      <td>142</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.45</td>
      <td>0.54</td>
      <td>2</td>
      <td>135</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.11</td>
      <td>0.81</td>
      <td>6</td>
      <td>305</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.84</td>
      <td>0.92</td>
      <td>4</td>
      <td>234</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.41</td>
      <td>0.55</td>
      <td>2</td>
      <td>148</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.36</td>
      <td>0.56</td>
      <td>2</td>
      <td>137</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.38</td>
      <td>0.54</td>
      <td>2</td>
      <td>143</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.45</td>
      <td>0.47</td>
      <td>2</td>
      <td>160</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.78</td>
      <td>0.99</td>
      <td>4</td>
      <td>255</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.45</td>
      <td>0.51</td>
      <td>2</td>
      <td>160</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.76</td>
      <td>0.89</td>
      <td>5</td>
      <td>262</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
  </tbody>
</table>
</div>




```python
# group by left
left = d[d.left==1]
```


```python
left.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>last_evaluation</th>
      <th>number_project</th>
      <th>average_montly_hours</th>
      <th>time_spend_company</th>
      <th>Work_accident</th>
      <th>left</th>
      <th>promotion_last_5years</th>
      <th>Department</th>
      <th>salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.38</td>
      <td>0.53</td>
      <td>2</td>
      <td>157</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.80</td>
      <td>0.86</td>
      <td>5</td>
      <td>262</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.11</td>
      <td>0.88</td>
      <td>7</td>
      <td>272</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.72</td>
      <td>0.87</td>
      <td>5</td>
      <td>223</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.37</td>
      <td>0.52</td>
      <td>2</td>
      <td>159</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
  </tbody>
</table>
</div>




```python
left.shape
```




    (3571, 10)




```python
retained = d[d.left==0]
```


```python
retained.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>last_evaluation</th>
      <th>number_project</th>
      <th>average_montly_hours</th>
      <th>time_spend_company</th>
      <th>Work_accident</th>
      <th>left</th>
      <th>promotion_last_5years</th>
      <th>Department</th>
      <th>salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2000</th>
      <td>0.58</td>
      <td>0.74</td>
      <td>4</td>
      <td>215</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>2001</th>
      <td>0.82</td>
      <td>0.67</td>
      <td>2</td>
      <td>202</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>2002</th>
      <td>0.45</td>
      <td>0.69</td>
      <td>5</td>
      <td>193</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>2003</th>
      <td>0.78</td>
      <td>0.82</td>
      <td>5</td>
      <td>247</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
    <tr>
      <th>2004</th>
      <td>0.49</td>
      <td>0.60</td>
      <td>3</td>
      <td>214</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
    </tr>
  </tbody>
</table>
</div>




```python
retained.shape
```




    (11428, 10)




```python
d1 = d.groupby('left').mean()
```


```python
d1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>last_evaluation</th>
      <th>number_project</th>
      <th>average_montly_hours</th>
      <th>time_spend_company</th>
      <th>Work_accident</th>
      <th>promotion_last_5years</th>
    </tr>
    <tr>
      <th>left</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.666810</td>
      <td>0.715473</td>
      <td>3.786664</td>
      <td>199.060203</td>
      <td>3.380032</td>
      <td>0.175009</td>
      <td>0.026251</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.440098</td>
      <td>0.718113</td>
      <td>3.855503</td>
      <td>207.419210</td>
      <td>3.876505</td>
      <td>0.047326</td>
      <td>0.005321</td>
    </tr>
  </tbody>
</table>
</div>




```python
# impact of salary
sns.barplot(d.left, d.salary)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='left', ylabel='salary'>




    
![png](output_79_2.png)
    



```python
# get dummy variable for salary
d2 = pd.get_dummies(d.salary)
```


```python
d2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>high</th>
      <th>low</th>
      <th>medium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d = pd.concat([d,d2], axis=1)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>last_evaluation</th>
      <th>number_project</th>
      <th>average_montly_hours</th>
      <th>time_spend_company</th>
      <th>Work_accident</th>
      <th>left</th>
      <th>promotion_last_5years</th>
      <th>Department</th>
      <th>salary</th>
      <th>high</th>
      <th>low</th>
      <th>medium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.38</td>
      <td>0.53</td>
      <td>2</td>
      <td>157</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.80</td>
      <td>0.86</td>
      <td>5</td>
      <td>262</td>
      <td>6</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.11</td>
      <td>0.88</td>
      <td>7</td>
      <td>272</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>medium</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.72</td>
      <td>0.87</td>
      <td>5</td>
      <td>223</td>
      <td>5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.37</td>
      <td>0.52</td>
      <td>2</td>
      <td>159</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>sales</td>
      <td>low</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = d[['satisfaction_level','average_montly_hours','promotion_last_5years','high','low','medium']]
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>satisfaction_level</th>
      <th>average_montly_hours</th>
      <th>promotion_last_5years</th>
      <th>high</th>
      <th>low</th>
      <th>medium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.38</td>
      <td>157</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.80</td>
      <td>262</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.11</td>
      <td>272</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.72</td>
      <td>223</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.37</td>
      <td>159</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d[['left']]
```


```python
y.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>left</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=1)
```


```python
from sklearn.linear_model import LogisticRegression
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    LogisticRegression()




```python
model.predict([[0.80,262,0,0,0,1]])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but LogisticRegression was fitted with feature names
      warnings.warn(
    




    array([0], dtype=int64)




```python
model.score(X_test, y_test)
```




    0.7733333333333333



---

##  Logistic Regression (Multiclass Classification)


```python
%matplotlib inline
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
from sklearn.datasets import load_digits
```


```python
digits = load_digits()
dir(digits)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'images', 'target', 'target_names']




```python
digits.data[0]
```




    array([ 0.,  0.,  5., 13.,  9.,  1.,  0.,  0.,  0.,  0., 13., 15., 10.,
           15.,  5.,  0.,  0.,  3., 15.,  2.,  0., 11.,  8.,  0.,  0.,  4.,
           12.,  0.,  0.,  8.,  8.,  0.,  0.,  5.,  8.,  0.,  0.,  9.,  8.,
            0.,  0.,  4., 11.,  0.,  1., 12.,  7.,  0.,  0.,  2., 14.,  5.,
           10., 12.,  0.,  0.,  0.,  0.,  6., 13., 10.,  0.,  0.,  0.])




```python
plt.gray()
for i in range(5):
    plt.matshow(digits.images[i])
```


    <Figure size 432x288 with 0 Axes>



    
![png](output_99_1.png)
    



    
![png](output_99_2.png)
    



    
![png](output_99_3.png)
    



    
![png](output_99_4.png)
    



    
![png](output_99_5.png)
    



```python
digits.target[0:5]
```




    array([0, 1, 2, 3, 4])




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(digits.data, digits.target, test_size=0.2)
```


```python
from sklearn.linear_model import LogisticRegression
```


```python
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.9694444444444444




```python
plt.matshow(digits.images[76])
```




    <matplotlib.image.AxesImage at 0x20491bcd060>




    
![png](output_107_1.png)
    



```python
digits.target[76]
```




    8




```python
model.predict(digits.data[[76]])
```




    array([8])




```python
y_pred = model.predict(X_test)
```


```python
model.predict(digits.data[0:5])
```




    array([0, 1, 2, 3, 4])




```python
# confusion matrix
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, y_pred)
```


```python
cm
```




    array([[36,  0,  0,  0,  0,  1,  0,  0,  0,  0],
           [ 0, 31,  0,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0, 27,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0,  0, 36,  0,  1,  0,  0,  1,  1],
           [ 0,  0,  0,  0, 40,  0,  0,  0,  0,  0],
           [ 0,  0,  0,  0,  0, 36,  0,  0,  0,  2],
           [ 0,  0,  0,  0,  0,  0, 33,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0,  0, 33,  0,  0],
           [ 0,  1,  0,  0,  0,  0,  1,  0, 31,  0],
           [ 0,  0,  0,  2,  0,  0,  0,  0,  1, 46]], dtype=int64)




```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_115_1.png)
    



```python
d = sns.load_dataset('iris')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = d.drop(['species'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d[['species']]
```


```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2)
```


```python
from sklearn.linear_model import LogisticRegression
```


```python
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.9666666666666667




```python
model.predict([[5.1,3.5,1.4,0.2]])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but LogisticRegression was fitted with feature names
      warnings.warn(
    




    array(['setosa'], dtype=object)




```python
y_pred = model.predict(X_test)
```


```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, y_pred)
```


```python
cm
```




    array([[10,  0,  0],
           [ 0,  9,  0],
           [ 0,  1, 10]], dtype=int64)




```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_131_1.png)
    


---

## Decision Tree


```python
import pandas as pd
```


```python
d = pd.read_csv('https://raw.githubusercontent.com/codebasics/py/master/ML/9_decision_tree/Exercise/titanic.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
d2 = d[['Survived','Sex','Age','Fare']]
```


```python
d2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Sex</th>
      <th>Age</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>male</td>
      <td>22.0</td>
      <td>7.2500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>female</td>
      <td>38.0</td>
      <td>71.2833</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>female</td>
      <td>26.0</td>
      <td>7.9250</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>female</td>
      <td>35.0</td>
      <td>53.1000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>male</td>
      <td>35.0</td>
      <td>8.0500</td>
    </tr>
  </tbody>
</table>
</div>




```python
d2.isnull().sum()
```




    Survived      0
    Sex           0
    Age         177
    Fare          0
    dtype: int64




```python
d1 = pd.get_dummies(d1['Sex'])

```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3360             try:
    -> 3361                 return self._engine.get_loc(casted_key)
       3362             except KeyError as err:
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'Sex'

    
    The above exception was the direct cause of the following exception:
    

    KeyError                                  Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_5616/2536469046.py in <module>
    ----> 1 d1 = pd.get_dummies(d1['Sex'])
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\pandas\core\frame.py in __getitem__(self, key)
       3456             if self.columns.nlevels > 1:
       3457                 return self._getitem_multilevel(key)
    -> 3458             indexer = self.columns.get_loc(key)
       3459             if is_integer(indexer):
       3460                 indexer = [indexer]
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3361                 return self._engine.get_loc(casted_key)
       3362             except KeyError as err:
    -> 3363                 raise KeyError(key) from err
       3364 
       3365         if is_scalar(key) and isna(key) and not self.hasnans:
    

    KeyError: 'Sex'



```python
d1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>888</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>889</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 2 columns</p>
</div>




```python
d3 = pd.concat([d2,d1], axis=1)
```


```python
d3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Sex</th>
      <th>Age</th>
      <th>Fare</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>male</td>
      <td>22.0</td>
      <td>7.2500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>female</td>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>female</td>
      <td>26.0</td>
      <td>7.9250</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>female</td>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>male</td>
      <td>35.0</td>
      <td>8.0500</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d3.drop(['Sex'], axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Age</th>
      <th>Fare</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>22.0</td>
      <td>7.2500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>26.0</td>
      <td>7.9250</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>35.0</td>
      <td>8.0500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>27.0</td>
      <td>13.0000</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>19.0</td>
      <td>30.0000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>NaN</td>
      <td>23.4500</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>26.0</td>
      <td>30.0000</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>32.0</td>
      <td>7.7500</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 5 columns</p>
</div>




```python
d3.Age = d3.Age.fillna(d3.Age.mean())
```


```python
d3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Sex</th>
      <th>Age</th>
      <th>Fare</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>male</td>
      <td>22.0</td>
      <td>7.2500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>female</td>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>female</td>
      <td>26.0</td>
      <td>7.9250</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>female</td>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>male</td>
      <td>35.0</td>
      <td>8.0500</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d3.isnull().sum()
```




    Survived    0
    Sex         0
    Age         0
    Fare        0
    female      0
    male        0
    dtype: int64




```python
X = d3.drop(['Sex','Survived'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Fare</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22.0</td>
      <td>7.2500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26.0</td>
      <td>7.9250</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>35.0</td>
      <td>8.0500</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d3[['Survived']]
```


```python
y.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2)
```


```python
from sklearn.tree import DecisionTreeClassifier
```


```python
model = DecisionTreeClassifier()
```


```python
model.fit(X,y)
```




    DecisionTreeClassifier()




```python
model.score(X_test, y_test)
```




    0.9776536312849162




```python
model.predict([[25,16,1,0]])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but DecisionTreeClassifier was fitted with feature names
      warnings.warn(
    




    array([1], dtype=int64)




```python
get_n_leaves()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_5616/1577200791.py in <module>
    ----> 1 get_n_leaves()
    

    NameError: name 'get_n_leaves' is not defined



```python
!pip install graphviz

!pip install pydotplus
```

    Collecting graphviz
      Downloading graphviz-0.19.1-py3-none-any.whl (46 kB)
         -------------------------------------- 46.3/46.3 KB 192.8 kB/s eta 0:00:00
    Installing collected packages: graphviz
    Successfully installed graphviz-0.19.1
    Collecting pydotplus
      Downloading pydotplus-2.0.2.tar.gz (278 kB)
         ------------------------------------ 278.7/278.7 KB 281.7 kB/s eta 0:00:00
      Preparing metadata (setup.py): started
      Preparing metadata (setup.py): finished with status 'done'
    Requirement already satisfied: pyparsing>=2.0.1 in c:\users\gulfam\appdata\local\programs\python\python310\lib\site-packages (from pydotplus) (3.0.6)
    Using legacy 'setup.py install' for pydotplus, since package 'wheel' is not installed.
    Installing collected packages: pydotplus
      Running setup.py install for pydotplus: started
      Running setup.py install for pydotplus: finished with status 'done'
    Successfully installed pydotplus-2.0.2
    


```python
from sklearn import tree
```


```python
# Print Text Representation
text_representation = tree.export_text(model)
print(text_representation)
```

    |--- feature_2 <= 0.50
    |   |--- feature_0 <= 6.50
    |   |   |--- feature_1 <= 20.83
    |   |   |   |--- class: 1
    |   |   |--- feature_1 >  20.83
    |   |   |   |--- feature_0 <= 0.96
    |   |   |   |   |--- class: 1
    |   |   |   |--- feature_0 >  0.96
    |   |   |   |   |--- feature_1 <= 64.38
    |   |   |   |   |   |--- feature_1 <= 39.34
    |   |   |   |   |   |   |--- feature_1 <= 31.33
    |   |   |   |   |   |   |   |--- feature_1 <= 26.95
    |   |   |   |   |   |   |   |   |--- feature_1 <= 23.54
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_1 >  23.54
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_1 >  26.95
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  31.33
    |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |--- feature_1 >  39.34
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |--- feature_1 >  64.38
    |   |   |   |   |   |--- class: 1
    |   |--- feature_0 >  6.50
    |   |   |--- feature_1 <= 26.27
    |   |   |   |--- feature_0 <= 13.50
    |   |   |   |   |--- feature_1 <= 17.34
    |   |   |   |   |   |--- class: 1
    |   |   |   |   |--- feature_1 >  17.34
    |   |   |   |   |   |--- feature_1 <= 19.66
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_1 >  19.66
    |   |   |   |   |   |   |--- class: 1
    |   |   |   |--- feature_0 >  13.50
    |   |   |   |   |--- feature_0 <= 32.50
    |   |   |   |   |   |--- feature_0 <= 30.75
    |   |   |   |   |   |   |--- feature_1 <= 23.35
    |   |   |   |   |   |   |   |--- feature_1 <= 22.89
    |   |   |   |   |   |   |   |   |--- feature_1 <= 15.17
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 29.35
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 28.75
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 10
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  28.75
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 7
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  29.35
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 8.08
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 6
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  8.08
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 7
    |   |   |   |   |   |   |   |   |--- feature_1 >  15.17
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 15.37
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  15.37
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 27.00
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  27.00
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |--- feature_1 >  22.89
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |--- feature_1 >  23.35
    |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_0 >  30.75
    |   |   |   |   |   |   |--- feature_1 <= 7.81
    |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  7.81
    |   |   |   |   |   |   |   |--- feature_1 <= 7.88
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_1 >  7.88
    |   |   |   |   |   |   |   |   |--- feature_1 <= 7.91
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_1 >  7.91
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 8.21
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 31.50
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  31.50
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  8.21
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 11.75
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  11.75
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |--- feature_0 >  32.50
    |   |   |   |   |   |--- feature_1 <= 7.91
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_1 >  7.91
    |   |   |   |   |   |   |--- feature_1 <= 7.99
    |   |   |   |   |   |   |   |--- feature_0 <= 38.00
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |--- feature_0 >  38.00
    |   |   |   |   |   |   |   |   |--- feature_0 <= 41.50
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_0 >  41.50
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |--- feature_1 >  7.99
    |   |   |   |   |   |   |   |--- feature_1 <= 13.25
    |   |   |   |   |   |   |   |   |--- feature_0 <= 59.50
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 12.94
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 44.50
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  44.50
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  12.94
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 45.00
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  45.00
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_0 >  59.50
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 64.00
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  64.00
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |--- feature_1 >  13.25
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |--- feature_1 >  26.27
    |   |   |   |--- feature_1 <= 26.47
    |   |   |   |   |--- class: 1
    |   |   |   |--- feature_1 >  26.47
    |   |   |   |   |--- feature_1 <= 387.66
    |   |   |   |   |   |--- feature_0 <= 22.50
    |   |   |   |   |   |   |--- feature_1 <= 109.89
    |   |   |   |   |   |   |   |--- feature_0 <= 8.50
    |   |   |   |   |   |   |   |   |--- feature_1 <= 32.94
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_1 >  32.94
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 7.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  7.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  8.50
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  109.89
    |   |   |   |   |   |   |   |--- feature_0 <= 18.00
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  18.00
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_0 >  22.50
    |   |   |   |   |   |   |--- feature_0 <= 27.50
    |   |   |   |   |   |   |   |--- feature_1 <= 151.29
    |   |   |   |   |   |   |   |   |--- feature_0 <= 25.50
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 23.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  23.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 24.50
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  24.50
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |--- feature_0 >  25.50
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_1 >  151.29
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_0 >  27.50
    |   |   |   |   |   |   |   |--- feature_0 <= 53.00
    |   |   |   |   |   |   |   |   |--- feature_1 <= 26.77
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 46.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 40.00
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  40.00
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  46.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |--- feature_1 >  26.77
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 29.10
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  29.10
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 30.60
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  30.60
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 8
    |   |   |   |   |   |   |   |--- feature_0 >  53.00
    |   |   |   |   |   |   |   |   |--- feature_0 <= 75.50
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 35.08
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  35.08
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 37.25
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  37.25
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |--- feature_0 >  75.50
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |--- feature_1 >  387.66
    |   |   |   |   |   |--- class: 1
    |--- feature_2 >  0.50
    |   |--- feature_1 <= 48.20
    |   |   |--- feature_1 <= 27.82
    |   |   |   |--- feature_1 <= 25.70
    |   |   |   |   |--- feature_1 <= 24.07
    |   |   |   |   |   |--- feature_1 <= 10.48
    |   |   |   |   |   |   |--- feature_1 <= 8.04
    |   |   |   |   |   |   |   |--- feature_0 <= 30.10
    |   |   |   |   |   |   |   |   |--- feature_1 <= 6.99
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_1 >  6.99
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 7.52
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  7.52
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 14.50
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  14.50
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 8
    |   |   |   |   |   |   |   |--- feature_0 >  30.10
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  8.04
    |   |   |   |   |   |   |   |--- feature_0 <= 19.00
    |   |   |   |   |   |   |   |   |--- feature_0 <= 10.00
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_0 >  10.00
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  19.00
    |   |   |   |   |   |   |   |   |--- feature_0 <= 51.50
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 30.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  30.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 9.08
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  9.08
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_0 >  51.50
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |--- feature_1 >  10.48
    |   |   |   |   |   |   |--- feature_1 <= 14.13
    |   |   |   |   |   |   |   |--- feature_0 <= 53.50
    |   |   |   |   |   |   |   |   |--- feature_0 <= 25.50
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 21.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  21.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 22.50
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  22.50
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |--- feature_0 >  25.50
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 37.00
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  37.00
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 39.00
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  39.00
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  53.50
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  14.13
    |   |   |   |   |   |   |   |--- feature_1 <= 15.37
    |   |   |   |   |   |   |   |   |--- feature_0 <= 29.35
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 28.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 14.75
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  14.75
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  28.50
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |--- feature_0 >  29.35
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |--- feature_1 >  15.37
    |   |   |   |   |   |   |   |   |--- feature_1 <= 17.60
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 25.00
    |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  25.00
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 27.85
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  27.85
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |--- feature_1 >  17.60
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 18.38
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  18.38
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 19.86
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  19.86
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |--- feature_1 >  24.07
    |   |   |   |   |   |--- feature_1 <= 24.81
    |   |   |   |   |   |   |--- feature_0 <= 19.85
    |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_0 >  19.85
    |   |   |   |   |   |   |   |--- feature_0 <= 29.85
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  29.85
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_1 >  24.81
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |--- feature_1 >  25.70
    |   |   |   |   |--- feature_0 <= 25.50
    |   |   |   |   |   |--- class: 1
    |   |   |   |   |--- feature_0 >  25.50
    |   |   |   |   |   |--- feature_0 <= 27.00
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_0 >  27.00
    |   |   |   |   |   |   |--- feature_0 <= 43.00
    |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |--- feature_0 >  43.00
    |   |   |   |   |   |   |   |--- feature_0 <= 44.50
    |   |   |   |   |   |   |   |   |--- feature_1 <= 26.86
    |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |--- feature_1 >  26.86
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_0 >  44.50
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |--- feature_1 >  27.82
    |   |   |   |--- feature_1 <= 28.86
    |   |   |   |   |--- class: 0
    |   |   |   |--- feature_1 >  28.86
    |   |   |   |   |--- feature_0 <= 38.50
    |   |   |   |   |   |--- feature_0 <= 21.50
    |   |   |   |   |   |   |--- feature_1 <= 30.67
    |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |--- feature_1 >  30.67
    |   |   |   |   |   |   |   |--- feature_1 <= 31.33
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |--- feature_1 >  31.33
    |   |   |   |   |   |   |   |   |--- feature_0 <= 7.50
    |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |--- feature_0 >  7.50
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 36.89
    |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  36.89
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 43.15
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  43.15
    |   |   |   |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_0 >  21.50
    |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |--- feature_0 >  38.50
    |   |   |   |   |   |--- feature_1 <= 36.69
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_1 >  36.69
    |   |   |   |   |   |   |--- feature_1 <= 39.64
    |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |--- feature_1 >  39.64
    |   |   |   |   |   |   |   |--- class: 0
    |   |--- feature_1 >  48.20
    |   |   |--- feature_0 <= 8.00
    |   |   |   |--- class: 0
    |   |   |--- feature_0 >  8.00
    |   |   |   |--- feature_0 <= 29.85
    |   |   |   |   |--- feature_0 <= 24.50
    |   |   |   |   |   |--- class: 1
    |   |   |   |   |--- feature_0 >  24.50
    |   |   |   |   |   |--- feature_0 <= 25.50
    |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |--- feature_0 >  25.50
    |   |   |   |   |   |   |--- feature_1 <= 74.20
    |   |   |   |   |   |   |   |--- feature_1 <= 62.28
    |   |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |   |   |   |   |--- feature_1 >  62.28
    |   |   |   |   |   |   |   |   |--- class: 0
    |   |   |   |   |   |   |--- feature_1 >  74.20
    |   |   |   |   |   |   |   |--- class: 1
    |   |   |   |--- feature_0 >  29.85
    |   |   |   |   |--- class: 1
    
    


```python
from sklearn.tree import plot_tree
plot_tree(model, filled=True)
plt.title("Decision tree trained on Titanic features")
plt.show()

```


    
![png](output_164_0.png)
    


---

## KNN


```python
from sklearn.datasets import load_boston
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
boston = load_boston()
```


```python
boston.keys()
```




    dict_keys(['data', 'target', 'feature_names', 'DESCR', 'filename', 'data_module'])




```python
boston.feature_names
```




    array(['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD',
           'TAX', 'PTRATIO', 'B', 'LSTAT'], dtype='<U7')




```python
boston.DESCR
```




    ".. _boston_dataset:\n\nBoston house prices dataset\n---------------------------\n\n**Data Set Characteristics:**  \n\n    :Number of Instances: 506 \n\n    :Number of Attributes: 13 numeric/categorical predictive. Median Value (attribute 14) is usually the target.\n\n    :Attribute Information (in order):\n        - CRIM     per capita crime rate by town\n        - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.\n        - INDUS    proportion of non-retail business acres per town\n        - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)\n        - NOX      nitric oxides concentration (parts per 10 million)\n        - RM       average number of rooms per dwelling\n        - AGE      proportion of owner-occupied units built prior to 1940\n        - DIS      weighted distances to five Boston employment centres\n        - RAD      index of accessibility to radial highways\n        - TAX      full-value property-tax rate per $10,000\n        - PTRATIO  pupil-teacher ratio by town\n        - B        1000(Bk - 0.63)^2 where Bk is the proportion of black people by town\n        - LSTAT    % lower status of the population\n        - MEDV     Median value of owner-occupied homes in $1000's\n\n    :Missing Attribute Values: None\n\n    :Creator: Harrison, D. and Rubinfeld, D.L.\n\nThis is a copy of UCI ML housing dataset.\nhttps://archive.ics.uci.edu/ml/machine-learning-databases/housing/\n\n\nThis dataset was taken from the StatLib library which is maintained at Carnegie Mellon University.\n\nThe Boston house-price data of Harrison, D. and Rubinfeld, D.L. 'Hedonic\nprices and the demand for clean air', J. Environ. Economics & Management,\nvol.5, 81-102, 1978.   Used in Belsley, Kuh & Welsch, 'Regression diagnostics\n...', Wiley, 1980.   N.B. Various transformations are used in the table on\npages 244-261 of the latter.\n\nThe Boston house-price data has been used in many machine learning papers that address regression\nproblems.   \n     \n.. topic:: References\n\n   - Belsley, Kuh & Welsch, 'Regression diagnostics: Identifying Influential Data and Sources of Collinearity', Wiley, 1980. 244-261.\n   - Quinlan,R. (1993). Combining Instance-Based and Model-Based Learning. In Proceedings on the Tenth International Conference of Machine Learning, 236-243, University of Massachusetts, Amherst. Morgan Kaufmann.\n"




```python
boston.data.shape
```




    (506, 13)




```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
d.keys()
```




    dict_keys(['data', 'target', 'frame', 'target_names', 'DESCR', 'feature_names', 'filename', 'data_module'])




```python
d.feature_names
```




    ['sepal length (cm)',
     'sepal width (cm)',
     'petal length (cm)',
     'petal width (cm)']




```python
d.data.shape
```




    (150, 4)




```python
d.target_names
```




    array(['setosa', 'versicolor', 'virginica'], dtype='<U10')




```python
X = d['data']
```


```python
y = d['target']
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
```


```python
X_train.shape
```




    (120, 4)




```python
df = pd.DataFrame(X_train, columns=d.feature_names)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6.4</td>
      <td>3.1</td>
      <td>5.5</td>
      <td>1.8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.4</td>
      <td>3.0</td>
      <td>4.5</td>
      <td>1.5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5.2</td>
      <td>3.5</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6.1</td>
      <td>3.0</td>
      <td>4.9</td>
      <td>1.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6.4</td>
      <td>2.8</td>
      <td>5.6</td>
      <td>2.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.pairplot(df)
```




    <seaborn.axisgrid.PairGrid at 0x2280facc220>




    
![png](output_186_1.png)
    



```python
from sklearn.neighbors import KNeighborsClassifier
```


```python
knn = KNeighborsClassifier(n_neighbors=3)
```


```python
knn.fit(X_train, y_train)
```




    KNeighborsClassifier(n_neighbors=3)




```python
knn.predict([[5,2.9,1,0.2]])
```




    array([0])




```python
y_pred = knn.predict(X_test)
```


```python
y_pred
```




    array([2, 1, 0, 2, 0, 2, 0, 1, 1, 1, 2, 1, 1, 1, 2, 0, 1, 1, 0, 0, 2, 1,
           0, 0, 2, 0, 0, 1, 1, 0])




```python
from sklearn.metrics import accuracy_score
```


```python
score = accuracy_score(y_test, y_pred)
```


```python
score
```




    0.9666666666666667




```python
knn.score(X_test, y_test)
```




    0.9666666666666667




```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, y_pred)
```


```python
cm
```




    array([[11,  0,  0],
           [ 0, 12,  1],
           [ 0,  0,  6]], dtype=int64)




```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_200_1.png)
    



```python
# evaluating training and test set performance
from sklearn.datasets import load_breast_cancer
```


```python
d = load_breast_cancer()
```


```python
d.keys()
```




    dict_keys(['data', 'target', 'frame', 'target_names', 'DESCR', 'feature_names', 'filename', 'data_module'])




```python
d.feature_names
```




    array(['mean radius', 'mean texture', 'mean perimeter', 'mean area',
           'mean smoothness', 'mean compactness', 'mean concavity',
           'mean concave points', 'mean symmetry', 'mean fractal dimension',
           'radius error', 'texture error', 'perimeter error', 'area error',
           'smoothness error', 'compactness error', 'concavity error',
           'concave points error', 'symmetry error',
           'fractal dimension error', 'worst radius', 'worst texture',
           'worst perimeter', 'worst area', 'worst smoothness',
           'worst compactness', 'worst concavity', 'worst concave points',
           'worst symmetry', 'worst fractal dimension'], dtype='<U23')




```python
d.target_names
```




    array(['malignant', 'benign'], dtype='<U9')




```python
X = d['data']
```


```python
y = d['target']
```


```python
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, stratify=y, random_state=0)
```


```python
training_accuracy=[]
test_accuracy = []
neighbors = range(1,11)
for n_neighbors in neighbors:
    knn = KNeighborsClassifier(n_neighbors=n_neighbors)
    knn.fit(X_train, y_train)
    training_accuracy.append(knn.score(X_train, y_train))
    test_accuracy.append(knn.score(X_test, y_test))

plt.plot(neighbors, training_accuracy, label='training_accuracy')
plt.plot(neighbors, test_accuracy, label='test_accuracy')
plt.ylabel("Accuracy")
plt.xlabel("n_neighbors")

plt.legend()
```




    <matplotlib.legend.Legend at 0x2281053fe20>




    
![png](output_210_1.png)
    


---

## SVM


```python
import pandas as pd
import numpy as np
```


```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
dir(d)
```




    ['DESCR',
     'data',
     'data_module',
     'feature_names',
     'filename',
     'frame',
     'target',
     'target_names']




```python
d.feature_names
```




    ['sepal length (cm)',
     'sepal width (cm)',
     'petal length (cm)',
     'petal width (cm)']




```python
df = pd.DataFrame(d.data, columns=d.feature_names)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.target_names
```




    array(['setosa', 'versicolor', 'virginica'], dtype='<U10')




```python
df['target']=d.target
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[df.target==1].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>50</th>
      <td>7.0</td>
      <td>3.2</td>
      <td>4.7</td>
      <td>1.4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>51</th>
      <td>6.4</td>
      <td>3.2</td>
      <td>4.5</td>
      <td>1.5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>52</th>
      <td>6.9</td>
      <td>3.1</td>
      <td>4.9</td>
      <td>1.5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>53</th>
      <td>5.5</td>
      <td>2.3</td>
      <td>4.0</td>
      <td>1.3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>54</th>
      <td>6.5</td>
      <td>2.8</td>
      <td>4.6</td>
      <td>1.5</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (150, 5)




```python
import matplotlib.pyplot as plt
```


```python
%matplotlib inline
df0 = df[df.target==0]
df1 = df[df.target==1]
df2 = df[df.target==2]
```


```python
df0.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(df0['sepal length (cm)'], df0['sepal width (cm)'],color='blue', marker='+')
plt.scatter(df1['sepal length (cm)'], df1['sepal width (cm)'],color='red', marker='o')
plt.scatter(df2['sepal length (cm)'], df2['sepal width (cm)'],color='orange', marker='*')
```




    <matplotlib.collections.PathCollection at 0x26a799d9d20>




    
![png](output_227_1.png)
    



```python
from sklearn.model_selection import train_test_split
```


```python
X = df.drop(['target'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = df['target']
```


```python
y.head()
```




    0    0
    1    0
    2    0
    3    0
    4    0
    Name: target, dtype: int32




```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
```


```python
len(X_train)
```




    120




```python
from sklearn.svm import SVC
```


```python
svc = SVC(kernel ='linear')
```


```python
svc.fit(X_train, y_train)
```




    SVC(kernel='linear')




```python
svc.score(X_test, y_test)
```




    1.0




```python
from sklearn.datasets import load_digits
```


```python
d = load_digits()
```


```python
dir(d)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'images', 'target', 'target_names']




```python
d.feature_names
```




    ['pixel_0_0',
     'pixel_0_1',
     'pixel_0_2',
     'pixel_0_3',
     'pixel_0_4',
     'pixel_0_5',
     'pixel_0_6',
     'pixel_0_7',
     'pixel_1_0',
     'pixel_1_1',
     'pixel_1_2',
     'pixel_1_3',
     'pixel_1_4',
     'pixel_1_5',
     'pixel_1_6',
     'pixel_1_7',
     'pixel_2_0',
     'pixel_2_1',
     'pixel_2_2',
     'pixel_2_3',
     'pixel_2_4',
     'pixel_2_5',
     'pixel_2_6',
     'pixel_2_7',
     'pixel_3_0',
     'pixel_3_1',
     'pixel_3_2',
     'pixel_3_3',
     'pixel_3_4',
     'pixel_3_5',
     'pixel_3_6',
     'pixel_3_7',
     'pixel_4_0',
     'pixel_4_1',
     'pixel_4_2',
     'pixel_4_3',
     'pixel_4_4',
     'pixel_4_5',
     'pixel_4_6',
     'pixel_4_7',
     'pixel_5_0',
     'pixel_5_1',
     'pixel_5_2',
     'pixel_5_3',
     'pixel_5_4',
     'pixel_5_5',
     'pixel_5_6',
     'pixel_5_7',
     'pixel_6_0',
     'pixel_6_1',
     'pixel_6_2',
     'pixel_6_3',
     'pixel_6_4',
     'pixel_6_5',
     'pixel_6_6',
     'pixel_6_7',
     'pixel_7_0',
     'pixel_7_1',
     'pixel_7_2',
     'pixel_7_3',
     'pixel_7_4',
     'pixel_7_5',
     'pixel_7_6',
     'pixel_7_7']




```python
d.target[23]
```




    3



 X = pd.DataFrame(d.data)


```python
y =pd.DataFrame(d.target)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>54</th>
      <th>55</th>
      <th>56</th>
      <th>57</th>
      <th>58</th>
      <th>59</th>
      <th>60</th>
      <th>61</th>
      <th>62</th>
      <th>63</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>13.0</td>
      <td>9.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6.0</td>
      <td>13.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>13.0</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>16.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>15.0</td>
      <td>12.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>16.0</td>
      <td>9.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>15.0</td>
      <td>13.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>11.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 64 columns</p>
</div>




```python

```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X , y, test_size=0.2)
```


```python
len(X_train)
```




    1437




```python
from sklearn.svm import SVC
```


```python
svc = SVC()
```


```python
svc.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    SVC()




```python
svc.score(X_test, y_test)
```




    0.9833333333333333




```python
svc.predict(d.data[[23]])
```




    array([3])




```python
y_pred = svc.predict(X_test)
```


```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, y_pred)
```


```python
cm
```




    array([[41,  0,  0,  0,  1,  0,  0,  0,  0,  0],
           [ 0, 29,  0,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0, 40,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0,  0, 44,  0,  1,  0,  0,  0,  0],
           [ 0,  0,  0,  0, 38,  0,  0,  0,  0,  1],
           [ 0,  0,  0,  0,  0, 38,  1,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0, 28,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0,  0, 31,  0,  0],
           [ 0,  1,  0,  0,  0,  0,  0,  0, 35,  0],
           [ 0,  0,  0,  0,  0,  0,  0,  0,  1, 30]], dtype=int64)




```python
import seaborn as sns
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_260_1.png)
    


---

## Random Forest


```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
from sklearn.datasets import load_digits
```


```python
d = load_digits()
```


```python
dir(d)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'images', 'target', 'target_names']




```python
d.feature_names
```




    ['pixel_0_0',
     'pixel_0_1',
     'pixel_0_2',
     'pixel_0_3',
     'pixel_0_4',
     'pixel_0_5',
     'pixel_0_6',
     'pixel_0_7',
     'pixel_1_0',
     'pixel_1_1',
     'pixel_1_2',
     'pixel_1_3',
     'pixel_1_4',
     'pixel_1_5',
     'pixel_1_6',
     'pixel_1_7',
     'pixel_2_0',
     'pixel_2_1',
     'pixel_2_2',
     'pixel_2_3',
     'pixel_2_4',
     'pixel_2_5',
     'pixel_2_6',
     'pixel_2_7',
     'pixel_3_0',
     'pixel_3_1',
     'pixel_3_2',
     'pixel_3_3',
     'pixel_3_4',
     'pixel_3_5',
     'pixel_3_6',
     'pixel_3_7',
     'pixel_4_0',
     'pixel_4_1',
     'pixel_4_2',
     'pixel_4_3',
     'pixel_4_4',
     'pixel_4_5',
     'pixel_4_6',
     'pixel_4_7',
     'pixel_5_0',
     'pixel_5_1',
     'pixel_5_2',
     'pixel_5_3',
     'pixel_5_4',
     'pixel_5_5',
     'pixel_5_6',
     'pixel_5_7',
     'pixel_6_0',
     'pixel_6_1',
     'pixel_6_2',
     'pixel_6_3',
     'pixel_6_4',
     'pixel_6_5',
     'pixel_6_6',
     'pixel_6_7',
     'pixel_7_0',
     'pixel_7_1',
     'pixel_7_2',
     'pixel_7_3',
     'pixel_7_4',
     'pixel_7_5',
     'pixel_7_6',
     'pixel_7_7']




```python
%matplotlib inline
for i in range(5):
    plt.matshow(d.images[i])
```


    
![png](output_268_0.png)
    



    
![png](output_268_1.png)
    



    
![png](output_268_2.png)
    



    
![png](output_268_3.png)
    



    
![png](output_268_4.png)
    



```python
X = pd.DataFrame(d['data'])
```


```python
y = pd.DataFrame(d['target'])
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2)
```


```python
from sklearn.ensemble import RandomForestClassifier
```


```python
rfc = RandomForestClassifier()
```


```python
rfc.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_7104/1542427849.py:1: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      rfc.fit(X_train, y_train)
    




    RandomForestClassifier()




```python
rfc.score(X_test, y_test)
```




    0.9888888888888889




```python
y_pred = rfc.predict(X_test)
```


```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_pred, y_test)
```


```python
cm
```




    array([[40,  0,  0,  0,  0,  0,  1,  0,  0,  0],
           [ 0, 28,  0,  0,  0,  0,  0,  0,  1,  0],
           [ 0,  0, 42,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0,  0, 38,  0,  0,  0,  0,  0,  0],
           [ 1,  0,  0,  0, 40,  0,  0,  1,  0,  0],
           [ 0,  0,  0,  0,  0, 36,  0,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0, 29,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0,  0, 40,  0,  0],
           [ 0,  0,  0,  0,  0,  0,  0,  0, 24,  0],
           [ 0,  0,  0,  0,  0,  0,  0,  0,  0, 39]], dtype=int64)




```python
import seaborn as sns
```


```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_282_1.png)
    



```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
dir(d)
```




    ['DESCR',
     'data',
     'data_module',
     'feature_names',
     'filename',
     'frame',
     'target',
     'target_names']




```python
X = pd.DataFrame(d.data)
```


```python
y = pd.DataFrame(d.target)
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
```


```python
from sklearn.ensemble import RandomForestClassifier
```


```python
rfc = RandomForestClassifier(n_estimators=23)  # maximum accuracy at that minimum tree numbers
```


```python
rfc.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_7104/1542427849.py:1: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      rfc.fit(X_train, y_train)
    




    RandomForestClassifier(n_estimators=23)




```python
rfc.score(X_test, y_test)
```




    0.9666666666666667




```python
y_pred = rfc.predict(X_test)
```


```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_pred, y_test)
```


```python
cm
```




    array([[10,  0,  0],
           [ 0,  7,  1],
           [ 0,  0, 12]], dtype=int64)




```python
import seaborn as sns
```


```python
sns.heatmap(cm, annot=True)
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_5416/420206201.py in <module>
    ----> 1 sns.heatmap(cm, annot=True)
    

    NameError: name 'cm' is not defined


---

## K-Fold Cross Validation


```python
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
```


```python
from sklearn.datasets import load_digits
```


```python
d = load_digits()
```


```python
X = pd.DataFrame(d.data)
```


```python
y = pd.DataFrame(d.target)
```


```python
from sklearn.model_selection import StratifiedKFold
kf = StratifiedKFold(n_splits=10)
```


```python
from sklearn.model_selection import train_test_split
```


```python
def get_score(model, X_train, X_test, y_train, y_test):
    model.fit(X_train, y_train)
    return model.score(X_test, y_test)
```


```python
score_lr = []
score_svc = []
score_rfc = []

for train_index, test_index in kf.split(X,y):
    X_train, X_test, y_train, y_test = train_test_split(X, y)
    score_lr.append(get_score(LogisticRegression(), X_train, X_test, y_train, y_test))
    score_svc.append(get_score(SVC(), X_train, X_test, y_train, y_test))
    score_rfc.append(get_score(RandomForestClassifier(), X_train, X_test, y_train, y_test))
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Temp/ipykernel_5416/1764670271.py:2: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      model.fit(X_train, y_train)
    


```python

score_rfc
```




    [0.9755555555555555,
     0.9666666666666667,
     0.9622222222222222,
     0.9755555555555555,
     0.9733333333333334,
     0.9666666666666667,
     0.9666666666666667,
     0.98,
     0.9688888888888889,
     0.9911111111111112]




```python
score_lr 
```




    [0.9688888888888889,
     0.9622222222222222,
     0.9666666666666667,
     0.9666666666666667,
     0.9622222222222222,
     0.96,
     0.9666666666666667,
     0.9577777777777777,
     0.9577777777777777,
     0.9622222222222222]




```python
score_svc
```




    [0.9866666666666667,
     0.9888888888888889,
     0.9733333333333334,
     0.9888888888888889,
     0.9866666666666667,
     0.9777777777777777,
     0.9844444444444445,
     0.9888888888888889,
     0.9777777777777777,
     0.9977777777777778]



---

## Cross validation score


```python
from sklearn.model_selection import cross_val_score 
```


```python
cross_val_score(LogisticRegression(), d.data, d.target, n_jobs=10)
```




    array([0.92222222, 0.86944444, 0.94150418, 0.93871866, 0.89693593])




```python
cross_val_score(SVC(), d.data, d.target, n_jobs=10)
```




    array([0.96111111, 0.94444444, 0.98328691, 0.98885794, 0.93871866])




```python
cross_val_score(RandomForestClassifier(), d.data, d.target, n_jobs=10)
```




    array([0.93055556, 0.89722222, 0.9637883 , 0.96100279, 0.9275766 ])




```python
# tuning the parameters.....
cross_val_score(RandomForestClassifier(n_estimators=60), d.data, d.target, n_jobs=10)
```




    array([0.92222222, 0.90277778, 0.95543175, 0.94986072, 0.91643454])




```python
import pandas as pd
```


```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
dir(d)
```




    ['DESCR',
     'data',
     'data_module',
     'feature_names',
     'filename',
     'frame',
     'target',
     'target_names']




```python
X = pd.DataFrame(d.data)
```


```python
y = pd.DataFrame(d.target)
```


```python
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
```


```python
from sklearn.model_selection import cross_val_score
```


```python
cross_val_score(LogisticRegression(), X, y, n_jobs=None).mean()
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    0.9733333333333334




```python
cross_val_score(DecisionTreeClassifier(), X, y, n_jobs=None).mean()
```




    0.9600000000000002




```python
cross_val_score(SVC(), X, y, n_jobs=None).mean()
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    0.9666666666666666




```python
cross_val_score(RandomForestClassifier(), X, y).mean()
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\model_selection\_validation.py:680: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      estimator.fit(X_train, y_train, **fit_params)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\model_selection\_validation.py:680: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      estimator.fit(X_train, y_train, **fit_params)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\model_selection\_validation.py:680: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      estimator.fit(X_train, y_train, **fit_params)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\model_selection\_validation.py:680: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      estimator.fit(X_train, y_train, **fit_params)
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\model_selection\_validation.py:680: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples,), for example using ravel().
      estimator.fit(X_train, y_train, **fit_params)
    




    0.9533333333333334



---

## K-Means Clustering


```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
dir(d)
```




    ['DESCR',
     'data',
     'data_module',
     'feature_names',
     'filename',
     'frame',
     'target',
     'target_names']




```python
df = pd.DataFrame(d.data, columns = d.feature_names)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['target']= pd.DataFrame(d.target)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1 = df.drop(['sepal width (cm)','sepal length (cm)','target'], axis=1)
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1 = d1.rename({'petal length (cm)':'petal_length', 'petal width (cm)':'petal_width'}, axis=1)
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
pl = d1[['petal_length']]
```


```python
pw = d1[['petal_width']]
```


```python
plt.scatter(d1.petal_length, d1.petal_width)
```




    <matplotlib.collections.PathCollection at 0x1c12fab4a30>




    
![png](output_349_1.png)
    



```python
from sklearn.cluster import KMeans
```


```python
km = KMeans(n_clusters=2)
```


```python
y_pred = km.fit_predict(pl,pw)
```


```python
d1['cluster'] = y_pred
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1['cluster'].unique()
```




    array([0, 1])




```python

df1 = d1[d1.cluster==0]
df2 = d1[d1.cluster==1]

plt.scatter(df1.petal_length, df1.petal_width, color='red')
plt.scatter(df2.petal_length, df2.petal_width, color='green')

```




    <matplotlib.collections.PathCollection at 0x1c12fca5600>




    
![png](output_356_1.png)
    



```python
km.cluster_centers_
```




    array([[1.49215686],
           [4.92525253]])




```python
# Elbow method
k_range = range(1,10)
sse = []
for k in k_range:
    km = KMeans(n_clusters=k)
    km.fit_predict(pl,pw)
    sse.append(km.inertia_)
```


```python
plt.plot(k_range, sse)
```




    [<matplotlib.lines.Line2D at 0x1c12feb38b0>]




    
![png](output_359_1.png)
    



```python
sse
```




    [464.3253999999999,
     67.60373143196672,
     24.86289803921569,
     12.577511111111109,
     8.872690723311775,
     6.027751459676857,
     4.284058912655969,
     3.3945730095990947,
     2.5436428946160388]



---


## Naive Bayes Classifier


```python
import pandas as pd
import seaborn as sns
```


```python
d = sns.load_dataset('titanic')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>survived</th>
      <th>pclass</th>
      <th>sex</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>fare</th>
      <th>embarked</th>
      <th>class</th>
      <th>who</th>
      <th>adult_male</th>
      <th>deck</th>
      <th>embark_town</th>
      <th>alive</th>
      <th>alone</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>S</td>
      <td>Third</td>
      <td>man</td>
      <td>True</td>
      <td>NaN</td>
      <td>Southampton</td>
      <td>no</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>C</td>
      <td>First</td>
      <td>woman</td>
      <td>False</td>
      <td>C</td>
      <td>Cherbourg</td>
      <td>yes</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>3</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>S</td>
      <td>Third</td>
      <td>woman</td>
      <td>False</td>
      <td>NaN</td>
      <td>Southampton</td>
      <td>yes</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>S</td>
      <td>First</td>
      <td>woman</td>
      <td>False</td>
      <td>C</td>
      <td>Southampton</td>
      <td>yes</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>S</td>
      <td>Third</td>
      <td>man</td>
      <td>True</td>
      <td>NaN</td>
      <td>Southampton</td>
      <td>no</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1 = d[['sex','age','fare','pclass']]
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sex</th>
      <th>age</th>
      <th>fare</th>
      <th>pclass</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>male</td>
      <td>22.0</td>
      <td>7.2500</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>26.0</td>
      <td>7.9250</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>female</td>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>male</td>
      <td>35.0</td>
      <td>8.0500</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
d2 = pd.get_dummies(d1.sex)
```


```python
d2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d3 = pd.concat([d1,d2],axis=1)
```


```python
d3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sex</th>
      <th>age</th>
      <th>fare</th>
      <th>pclass</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>male</td>
      <td>22.0</td>
      <td>7.2500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>female</td>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>female</td>
      <td>26.0</td>
      <td>7.9250</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>female</td>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>male</td>
      <td>35.0</td>
      <td>8.0500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = d3.drop(['sex'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fare</th>
      <th>pclass</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22.0</td>
      <td>7.2500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26.0</td>
      <td>7.9250</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>35.0</td>
      <td>8.0500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
X.isnull().sum()
```




    age       177
    fare        0
    pclass      0
    female      0
    male        0
    dtype: int64




```python
X.age = X.age.fillna(X.age.mean())
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fare</th>
      <th>pclass</th>
      <th>female</th>
      <th>male</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22.0</td>
      <td>7.2500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38.0</td>
      <td>71.2833</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26.0</td>
      <td>7.9250</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>35.0</td>
      <td>53.1000</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>35.0</td>
      <td>8.0500</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d[['survived']]
```


```python
y.isnull().sum()
```




    survived    0
    dtype: int64




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
```


```python
from sklearn.naive_bayes import GaussianNB
```


```python
model = GaussianNB()
```


```python
model.fit(X_train,y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    GaussianNB()




```python
model.score(X_test, y_test)
```




    0.8044692737430168




```python
y_test[0:10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>survived</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>842</th>
      <td>1</td>
    </tr>
    <tr>
      <th>477</th>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1</td>
    </tr>
    <tr>
      <th>73</th>
      <td>0</td>
    </tr>
    <tr>
      <th>492</th>
      <td>0</td>
    </tr>
    <tr>
      <th>58</th>
      <td>1</td>
    </tr>
    <tr>
      <th>347</th>
      <td>1</td>
    </tr>
    <tr>
      <th>810</th>
      <td>0</td>
    </tr>
    <tr>
      <th>693</th>
      <td>0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
model.predict(X_test[0:10])
```




    array([1, 0, 1, 0, 0, 1, 1, 0, 0, 0], dtype=int64)




```python
model.predict_proba(X_test[0:10])
```




    array([[0.01007519, 0.98992481],
           [0.98991329, 0.01008671],
           [0.00945608, 0.99054392],
           [0.9896538 , 0.0103462 ],
           [0.90952114, 0.09047886],
           [0.01934299, 0.98065701],
           [0.08930673, 0.91069327],
           [0.98945366, 0.01054634],
           [0.98921117, 0.01078883],
           [0.97687442, 0.02312558]])



---

## Spam Mail Detection


```python
import pandas as pd
```


```python
d = pd.read_csv('D:/ds/ML/14_naive_bayes/spam.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
      <td>Go until jurong point, crazy.. Available only ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ham</td>
      <td>Ok lar... Joking wif u oni...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>spam</td>
      <td>Free entry in 2 a wkly comp to win FA Cup fina...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ham</td>
      <td>U dun say so early hor... U c already then say...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ham</td>
      <td>Nah I don't think he goes to usf, he lives aro...</td>
    </tr>
  </tbody>
</table>
</div>




```python
d['spam'] = d['Category'].apply(lambda x : 1 if x=='spam' else 0) 
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Message</th>
      <th>spam</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
      <td>Go until jurong point, crazy.. Available only ...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ham</td>
      <td>Ok lar... Joking wif u oni...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>spam</td>
      <td>Free entry in 2 a wkly comp to win FA Cup fina...</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ham</td>
      <td>U dun say so early hor... U c already then say...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ham</td>
      <td>Nah I don't think he goes to usf, he lives aro...</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(d.Message, d.spam, test_size = 0.2)
```


```python
# converting text into unique number matrix for each value
from sklearn.feature_extraction.text import CountVectorizer
v = CountVectorizer()
```


```python
X_train_count = v.fit_transform(X_train.values)
```


```python
X_train_count.toarray()[:3]
```




    array([[0, 0, 0, ..., 0, 0, 0],
           [0, 0, 0, ..., 0, 0, 0],
           [0, 0, 0, ..., 0, 0, 0]], dtype=int64)




```python
from sklearn.naive_bayes import MultinomialNB
model = MultinomialNB()
model.fit(X_train_count, y_train)
```




    MultinomialNB()




```python
emails = ['In Focus: ADBI at 25 Advances Ideas for Developing Asia’s Future, Public Procurement for Innovation, Building Pacific Research',
         'GULFAM MUSHTAQ, this job pays $30.00/hr in RENO, NV!']
```


```python
emails_count = v.transform(emails)
```


```python
model.predict(emails_count)
```




    array([0, 0], dtype=int64)




```python
# another way using pipeline function
from sklearn.pipeline import Pipeline
```


```python
clf = Pipeline([
    ('vectorizer',CountVectorizer()),
    ('nb', MultinomialNB())
])
```


```python
clf.fit(X_train, y_train)
```




    Pipeline(steps=[('vectorizer', CountVectorizer()), ('nb', MultinomialNB())])




```python
clf.predict(emails)
```




    array([0, 0], dtype=int64)




```python
clf.score(X_test, y_test)
```




    0.9883408071748879




```python
from sklearn.datasets import load_wine
```


```python
d = load_wine()
```


```python
dir(d)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'target', 'target_names']




```python
d.feature_names
```




    ['alcohol',
     'malic_acid',
     'ash',
     'alcalinity_of_ash',
     'magnesium',
     'total_phenols',
     'flavanoids',
     'nonflavanoid_phenols',
     'proanthocyanins',
     'color_intensity',
     'hue',
     'od280/od315_of_diluted_wines',
     'proline']




```python
d.target_names
```




    array(['class_0', 'class_1', 'class_2'], dtype='<U7')




```python
X = pd.DataFrame(d.data, columns=d.feature_names)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>alcohol</th>
      <th>malic_acid</th>
      <th>ash</th>
      <th>alcalinity_of_ash</th>
      <th>magnesium</th>
      <th>total_phenols</th>
      <th>flavanoids</th>
      <th>nonflavanoid_phenols</th>
      <th>proanthocyanins</th>
      <th>color_intensity</th>
      <th>hue</th>
      <th>od280/od315_of_diluted_wines</th>
      <th>proline</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>14.23</td>
      <td>1.71</td>
      <td>2.43</td>
      <td>15.6</td>
      <td>127.0</td>
      <td>2.80</td>
      <td>3.06</td>
      <td>0.28</td>
      <td>2.29</td>
      <td>5.64</td>
      <td>1.04</td>
      <td>3.92</td>
      <td>1065.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>13.20</td>
      <td>1.78</td>
      <td>2.14</td>
      <td>11.2</td>
      <td>100.0</td>
      <td>2.65</td>
      <td>2.76</td>
      <td>0.26</td>
      <td>1.28</td>
      <td>4.38</td>
      <td>1.05</td>
      <td>3.40</td>
      <td>1050.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13.16</td>
      <td>2.36</td>
      <td>2.67</td>
      <td>18.6</td>
      <td>101.0</td>
      <td>2.80</td>
      <td>3.24</td>
      <td>0.30</td>
      <td>2.81</td>
      <td>5.68</td>
      <td>1.03</td>
      <td>3.17</td>
      <td>1185.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>14.37</td>
      <td>1.95</td>
      <td>2.50</td>
      <td>16.8</td>
      <td>113.0</td>
      <td>3.85</td>
      <td>3.49</td>
      <td>0.24</td>
      <td>2.18</td>
      <td>7.80</td>
      <td>0.86</td>
      <td>3.45</td>
      <td>1480.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13.24</td>
      <td>2.59</td>
      <td>2.87</td>
      <td>21.0</td>
      <td>118.0</td>
      <td>2.80</td>
      <td>2.69</td>
      <td>0.39</td>
      <td>1.82</td>
      <td>4.32</td>
      <td>1.04</td>
      <td>2.93</td>
      <td>735.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = pd.DataFrame(d.target)
```


```python
y.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y , test_size=0.2)
```


```python
gnb = GaussianNB()
mnb = MultinomialNB()
```


```python
gnb.fit(X_train, y_train)

```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    GaussianNB()




```python
gnb.predict(X_test)
```




    array([1, 0, 1, 1, 1, 0, 0, 1, 2, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 0, 0, 2,
           0, 0, 1, 1, 2, 1, 2, 2, 0, 2, 2, 1, 0, 2])




```python
gnb.score(X_test, y_test)
```




    0.9722222222222222




```python
mnb.fit(X_train,y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    




    MultinomialNB()




```python
mnb.predict(X_test)
```




    array([1, 0, 1, 1, 1, 0, 0, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 0, 2,
           0, 0, 2, 1, 2, 1, 0, 2, 0, 1, 2, 1, 0, 2])




```python
mnb.score(X_test,y_test)
```




    0.8611111111111112



---

## Hyper Parameter Tuning(GridSearchCV)


```python
from sklearn.datasets import load_iris
```


```python
import pandas as pd
```


```python
d = load_iris()
```


```python
df = pd.DataFrame(d.data, columns=d.feature_names)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['flower'] = d.target
```


```python
df['flower'] = df['flower'].apply(lambda x: d.target_names[x])
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>flower</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(d.data, d.target, test_size=0.2)
```


```python
from sklearn.svm import SVC
```


```python
svc = SVC(kernel='rbf', C=30, gamma='auto')
```


```python
svc.fit(X_train, y_train)
svc.score(X_test, y_test)
```




    0.9




```python
from sklearn.model_selection import cross_val_score
```


```python
cross_val_score(SVC(kernel='rbf', C=30, gamma='auto'), d.data, d.target, cv=5).mean()
```




    0.96




```python
cross_val_score(SVC(kernel='rbf', C=20, gamma='auto'), d.data, d.target, cv=5).mean()
```




    0.9666666666666668




```python
import numpy as np
kernels = ['linear', 'poly', 'rbf', 'sigmoid']
C = [1,10,20,30]
gamma = ['scale', 'auto']
avg_scores = {}

for kval in kernels:
    for cval in C:
        for gval in gamma:
            
            cv_scores=cross_val_score(SVC(kernel=kval, C=cval,gamma=gval), d.data, d.target)
            avg_scores[kval+'_'+str(cval)+'_'+gval]= np.average(cv_scores)
avg_scores
```




    {'linear_1_scale': 0.9800000000000001,
     'linear_1_auto': 0.9800000000000001,
     'linear_10_scale': 0.9733333333333334,
     'linear_10_auto': 0.9733333333333334,
     'linear_20_scale': 0.9666666666666666,
     'linear_20_auto': 0.9666666666666666,
     'linear_30_scale': 0.96,
     'linear_30_auto': 0.96,
     'poly_1_scale': 0.9800000000000001,
     'poly_1_auto': 0.9666666666666666,
     'poly_10_scale': 0.9666666666666666,
     'poly_10_auto': 0.9666666666666666,
     'poly_20_scale': 0.9666666666666666,
     'poly_20_auto': 0.9533333333333334,
     'poly_30_scale': 0.9666666666666666,
     'poly_30_auto': 0.9533333333333334,
     'rbf_1_scale': 0.9666666666666666,
     'rbf_1_auto': 0.9800000000000001,
     'rbf_10_scale': 0.9800000000000001,
     'rbf_10_auto': 0.9800000000000001,
     'rbf_20_scale': 0.9800000000000001,
     'rbf_20_auto': 0.9666666666666668,
     'rbf_30_scale': 0.9733333333333334,
     'rbf_30_auto': 0.96,
     'sigmoid_1_scale': 0.06666666666666667,
     'sigmoid_1_auto': 0.09333333333333334,
     'sigmoid_10_scale': 0.05333333333333333,
     'sigmoid_10_auto': 0.09333333333333334,
     'sigmoid_20_scale': 0.039999999999999994,
     'sigmoid_20_auto': 0.09333333333333334,
     'sigmoid_30_scale': 0.039999999999999994,
     'sigmoid_30_auto': 0.09333333333333334}




```python
max(avg_scores, key=lambda key: avg_scores[key])
```




    'linear_1_scale'




```python
# or using gridsearch method;
from sklearn.model_selection import GridSearchCV

```


```python
clf = GridSearchCV(SVC(gamma='auto'),{
    'C':[1,10,20],
    'kernel':['rbf','linear','poly', 'sigmoid']
}, cv=5, return_train_score=False)

clf.fit(d.data, d.target)
clf.cv_results_
```




    {'mean_fit_time': array([0.00139885, 0.00059934, 0.00219746, 0.00219698, 0.00100017,
            0.00079889, 0.00459437, 0.00199714, 0.00079951, 0.00059929,
            0.00938959, 0.0023983 ]),
     'std_fit_time': array([4.89648552e-04, 4.89356405e-04, 1.16398006e-03, 3.99741193e-04,
            6.31807669e-04, 3.99446843e-04, 2.93543732e-03, 7.77697870e-07,
            3.99756471e-04, 4.89317472e-04, 7.83213310e-03, 4.89356312e-04]),
     'mean_score_time': array([0.000599  , 0.00060053, 0.00079985, 0.00079861, 0.00079851,
            0.00019984, 0.00059996, 0.0003993 , 0.00059953, 0.00059938,
            0.0010006 , 0.00079918]),
     'std_score_time': array([4.89083986e-04, 4.90330363e-04, 3.99926125e-04, 3.99307052e-04,
            3.99256735e-04, 3.99684906e-04, 4.89862534e-04, 4.89047160e-04,
            4.89512527e-04, 4.89395261e-04, 1.79938910e-06, 3.99589766e-04]),
     'param_C': masked_array(data=[1, 1, 1, 1, 10, 10, 10, 10, 20, 20, 20, 20],
                  mask=[False, False, False, False, False, False, False, False,
                        False, False, False, False],
            fill_value='?',
                 dtype=object),
     'param_kernel': masked_array(data=['rbf', 'linear', 'poly', 'sigmoid', 'rbf', 'linear',
                        'poly', 'sigmoid', 'rbf', 'linear', 'poly', 'sigmoid'],
                  mask=[False, False, False, False, False, False, False, False,
                        False, False, False, False],
            fill_value='?',
                 dtype=object),
     'params': [{'C': 1, 'kernel': 'rbf'},
      {'C': 1, 'kernel': 'linear'},
      {'C': 1, 'kernel': 'poly'},
      {'C': 1, 'kernel': 'sigmoid'},
      {'C': 10, 'kernel': 'rbf'},
      {'C': 10, 'kernel': 'linear'},
      {'C': 10, 'kernel': 'poly'},
      {'C': 10, 'kernel': 'sigmoid'},
      {'C': 20, 'kernel': 'rbf'},
      {'C': 20, 'kernel': 'linear'},
      {'C': 20, 'kernel': 'poly'},
      {'C': 20, 'kernel': 'sigmoid'}],
     'split0_test_score': array([0.96666667, 0.96666667, 1.        , 0.33333333, 0.96666667,
            1.        , 1.        , 0.33333333, 0.96666667, 1.        ,
            0.96666667, 0.33333333]),
     'split1_test_score': array([1.        , 1.        , 1.        , 0.1       , 1.        ,
            1.        , 1.        , 0.1       , 1.        , 1.        ,
            0.96666667, 0.1       ]),
     'split2_test_score': array([0.96666667, 0.96666667, 0.9       , 0.        , 0.96666667,
            0.9       , 0.9       , 0.        , 0.9       , 0.9       ,
            0.9       , 0.        ]),
     'split3_test_score': array([0.96666667, 0.96666667, 0.93333333, 0.03333333, 0.96666667,
            0.96666667, 0.93333333, 0.03333333, 0.96666667, 0.93333333,
            0.93333333, 0.03333333]),
     'split4_test_score': array([1., 1., 1., 0., 1., 1., 1., 0., 1., 1., 1., 0.]),
     'mean_test_score': array([0.98      , 0.98      , 0.96666667, 0.09333333, 0.98      ,
            0.97333333, 0.96666667, 0.09333333, 0.96666667, 0.96666667,
            0.95333333, 0.09333333]),
     'std_test_score': array([0.01632993, 0.01632993, 0.0421637 , 0.12543258, 0.01632993,
            0.03887301, 0.0421637 , 0.12543258, 0.03651484, 0.0421637 ,
            0.03399346, 0.12543258]),
     'rank_test_score': array([ 1,  1,  6, 10,  1,  4,  6, 10,  5,  6,  9, 10])}




```python
df = pd.DataFrame(clf.cv_results_)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean_fit_time</th>
      <th>std_fit_time</th>
      <th>mean_score_time</th>
      <th>std_score_time</th>
      <th>param_C</th>
      <th>param_kernel</th>
      <th>params</th>
      <th>split0_test_score</th>
      <th>split1_test_score</th>
      <th>split2_test_score</th>
      <th>split3_test_score</th>
      <th>split4_test_score</th>
      <th>mean_test_score</th>
      <th>std_test_score</th>
      <th>rank_test_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.001399</td>
      <td>4.896486e-04</td>
      <td>0.000599</td>
      <td>0.000489</td>
      <td>1</td>
      <td>rbf</td>
      <td>{'C': 1, 'kernel': 'rbf'}</td>
      <td>0.966667</td>
      <td>1.000000</td>
      <td>0.966667</td>
      <td>0.966667</td>
      <td>1.0</td>
      <td>0.980000</td>
      <td>0.016330</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.000599</td>
      <td>4.893564e-04</td>
      <td>0.000601</td>
      <td>0.000490</td>
      <td>1</td>
      <td>linear</td>
      <td>{'C': 1, 'kernel': 'linear'}</td>
      <td>0.966667</td>
      <td>1.000000</td>
      <td>0.966667</td>
      <td>0.966667</td>
      <td>1.0</td>
      <td>0.980000</td>
      <td>0.016330</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.002197</td>
      <td>1.163980e-03</td>
      <td>0.000800</td>
      <td>0.000400</td>
      <td>1</td>
      <td>poly</td>
      <td>{'C': 1, 'kernel': 'poly'}</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.900000</td>
      <td>0.933333</td>
      <td>1.0</td>
      <td>0.966667</td>
      <td>0.042164</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.002197</td>
      <td>3.997412e-04</td>
      <td>0.000799</td>
      <td>0.000399</td>
      <td>1</td>
      <td>sigmoid</td>
      <td>{'C': 1, 'kernel': 'sigmoid'}</td>
      <td>0.333333</td>
      <td>0.100000</td>
      <td>0.000000</td>
      <td>0.033333</td>
      <td>0.0</td>
      <td>0.093333</td>
      <td>0.125433</td>
      <td>10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.001000</td>
      <td>6.318077e-04</td>
      <td>0.000799</td>
      <td>0.000399</td>
      <td>10</td>
      <td>rbf</td>
      <td>{'C': 10, 'kernel': 'rbf'}</td>
      <td>0.966667</td>
      <td>1.000000</td>
      <td>0.966667</td>
      <td>0.966667</td>
      <td>1.0</td>
      <td>0.980000</td>
      <td>0.016330</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.000799</td>
      <td>3.994468e-04</td>
      <td>0.000200</td>
      <td>0.000400</td>
      <td>10</td>
      <td>linear</td>
      <td>{'C': 10, 'kernel': 'linear'}</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.900000</td>
      <td>0.966667</td>
      <td>1.0</td>
      <td>0.973333</td>
      <td>0.038873</td>
      <td>4</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.004594</td>
      <td>2.935437e-03</td>
      <td>0.000600</td>
      <td>0.000490</td>
      <td>10</td>
      <td>poly</td>
      <td>{'C': 10, 'kernel': 'poly'}</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.900000</td>
      <td>0.933333</td>
      <td>1.0</td>
      <td>0.966667</td>
      <td>0.042164</td>
      <td>6</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.001997</td>
      <td>7.776979e-07</td>
      <td>0.000399</td>
      <td>0.000489</td>
      <td>10</td>
      <td>sigmoid</td>
      <td>{'C': 10, 'kernel': 'sigmoid'}</td>
      <td>0.333333</td>
      <td>0.100000</td>
      <td>0.000000</td>
      <td>0.033333</td>
      <td>0.0</td>
      <td>0.093333</td>
      <td>0.125433</td>
      <td>10</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.000800</td>
      <td>3.997565e-04</td>
      <td>0.000600</td>
      <td>0.000490</td>
      <td>20</td>
      <td>rbf</td>
      <td>{'C': 20, 'kernel': 'rbf'}</td>
      <td>0.966667</td>
      <td>1.000000</td>
      <td>0.900000</td>
      <td>0.966667</td>
      <td>1.0</td>
      <td>0.966667</td>
      <td>0.036515</td>
      <td>5</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.000599</td>
      <td>4.893175e-04</td>
      <td>0.000599</td>
      <td>0.000489</td>
      <td>20</td>
      <td>linear</td>
      <td>{'C': 20, 'kernel': 'linear'}</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.900000</td>
      <td>0.933333</td>
      <td>1.0</td>
      <td>0.966667</td>
      <td>0.042164</td>
      <td>6</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.009390</td>
      <td>7.832133e-03</td>
      <td>0.001001</td>
      <td>0.000002</td>
      <td>20</td>
      <td>poly</td>
      <td>{'C': 20, 'kernel': 'poly'}</td>
      <td>0.966667</td>
      <td>0.966667</td>
      <td>0.900000</td>
      <td>0.933333</td>
      <td>1.0</td>
      <td>0.953333</td>
      <td>0.033993</td>
      <td>9</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.002398</td>
      <td>4.893563e-04</td>
      <td>0.000799</td>
      <td>0.000400</td>
      <td>20</td>
      <td>sigmoid</td>
      <td>{'C': 20, 'kernel': 'sigmoid'}</td>
      <td>0.333333</td>
      <td>0.100000</td>
      <td>0.000000</td>
      <td>0.033333</td>
      <td>0.0</td>
      <td>0.093333</td>
      <td>0.125433</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1 = df[['param_C','param_kernel','mean_test_score']]
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>param_C</th>
      <th>param_kernel</th>
      <th>mean_test_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>rbf</td>
      <td>0.980000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>linear</td>
      <td>0.980000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>poly</td>
      <td>0.966667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>sigmoid</td>
      <td>0.093333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10</td>
      <td>rbf</td>
      <td>0.980000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10</td>
      <td>linear</td>
      <td>0.973333</td>
    </tr>
    <tr>
      <th>6</th>
      <td>10</td>
      <td>poly</td>
      <td>0.966667</td>
    </tr>
    <tr>
      <th>7</th>
      <td>10</td>
      <td>sigmoid</td>
      <td>0.093333</td>
    </tr>
    <tr>
      <th>8</th>
      <td>20</td>
      <td>rbf</td>
      <td>0.966667</td>
    </tr>
    <tr>
      <th>9</th>
      <td>20</td>
      <td>linear</td>
      <td>0.966667</td>
    </tr>
    <tr>
      <th>10</th>
      <td>20</td>
      <td>poly</td>
      <td>0.953333</td>
    </tr>
    <tr>
      <th>11</th>
      <td>20</td>
      <td>sigmoid</td>
      <td>0.093333</td>
    </tr>
  </tbody>
</table>
</div>




```python
dir(df1)
```




    ['T',
     '_AXIS_LEN',
     '_AXIS_ORDERS',
     '_AXIS_REVERSED',
     '_AXIS_TO_AXIS_NUMBER',
     '_HANDLED_TYPES',
     '__abs__',
     '__add__',
     '__and__',
     '__annotations__',
     '__array__',
     '__array_priority__',
     '__array_ufunc__',
     '__array_wrap__',
     '__bool__',
     '__class__',
     '__contains__',
     '__copy__',
     '__deepcopy__',
     '__delattr__',
     '__delitem__',
     '__dict__',
     '__dir__',
     '__divmod__',
     '__doc__',
     '__eq__',
     '__finalize__',
     '__floordiv__',
     '__format__',
     '__ge__',
     '__getattr__',
     '__getattribute__',
     '__getitem__',
     '__getstate__',
     '__gt__',
     '__hash__',
     '__iadd__',
     '__iand__',
     '__ifloordiv__',
     '__imod__',
     '__imul__',
     '__init__',
     '__init_subclass__',
     '__invert__',
     '__ior__',
     '__ipow__',
     '__isub__',
     '__iter__',
     '__itruediv__',
     '__ixor__',
     '__le__',
     '__len__',
     '__lt__',
     '__matmul__',
     '__mod__',
     '__module__',
     '__mul__',
     '__ne__',
     '__neg__',
     '__new__',
     '__nonzero__',
     '__or__',
     '__pos__',
     '__pow__',
     '__radd__',
     '__rand__',
     '__rdivmod__',
     '__reduce__',
     '__reduce_ex__',
     '__repr__',
     '__rfloordiv__',
     '__rmatmul__',
     '__rmod__',
     '__rmul__',
     '__ror__',
     '__round__',
     '__rpow__',
     '__rsub__',
     '__rtruediv__',
     '__rxor__',
     '__setattr__',
     '__setitem__',
     '__setstate__',
     '__sizeof__',
     '__str__',
     '__sub__',
     '__subclasshook__',
     '__truediv__',
     '__weakref__',
     '__xor__',
     '_accessors',
     '_accum_func',
     '_add_numeric_operations',
     '_agg_by_level',
     '_agg_examples_doc',
     '_agg_summary_and_see_also_doc',
     '_align_frame',
     '_align_series',
     '_arith_method',
     '_as_manager',
     '_attrs',
     '_box_col_values',
     '_can_fast_transpose',
     '_check_inplace_and_allows_duplicate_labels',
     '_check_inplace_setting',
     '_check_is_chained_assignment_possible',
     '_check_label_or_level_ambiguity',
     '_check_setitem_copy',
     '_clear_item_cache',
     '_clip_with_one_bound',
     '_clip_with_scalar',
     '_cmp_method',
     '_combine_frame',
     '_consolidate',
     '_consolidate_inplace',
     '_construct_axes_dict',
     '_construct_axes_from_arguments',
     '_construct_result',
     '_constructor',
     '_constructor_sliced',
     '_convert',
     '_count_level',
     '_data',
     '_dir_additions',
     '_dir_deletions',
     '_dispatch_frame_op',
     '_drop_axis',
     '_drop_labels_or_levels',
     '_ensure_valid_index',
     '_find_valid_index',
     '_flags',
     '_from_arrays',
     '_from_mgr',
     '_get_agg_axis',
     '_get_axis',
     '_get_axis_name',
     '_get_axis_number',
     '_get_axis_resolvers',
     '_get_block_manager_axis',
     '_get_bool_data',
     '_get_cleaned_column_resolvers',
     '_get_column_array',
     '_get_index_resolvers',
     '_get_item_cache',
     '_get_label_or_level_values',
     '_get_numeric_data',
     '_get_value',
     '_getitem_bool_array',
     '_getitem_multilevel',
     '_gotitem',
     '_hidden_attrs',
     '_indexed_same',
     '_info_axis',
     '_info_axis_name',
     '_info_axis_number',
     '_info_repr',
     '_init_mgr',
     '_inplace_method',
     '_internal_names',
     '_internal_names_set',
     '_is_copy',
     '_is_homogeneous_type',
     '_is_label_or_level_reference',
     '_is_label_reference',
     '_is_level_reference',
     '_is_mixed_type',
     '_is_view',
     '_iset_item',
     '_iset_item_mgr',
     '_iset_not_inplace',
     '_item_cache',
     '_iter_column_arrays',
     '_ixs',
     '_join_compat',
     '_logical_func',
     '_logical_method',
     '_maybe_cache_changed',
     '_maybe_update_cacher',
     '_metadata',
     '_mgr',
     '_min_count_stat_function',
     '_needs_reindex_multi',
     '_protect_consolidate',
     '_reduce',
     '_reindex_axes',
     '_reindex_columns',
     '_reindex_index',
     '_reindex_multi',
     '_reindex_with_indexers',
     '_replace_columnwise',
     '_repr_data_resource_',
     '_repr_fits_horizontal_',
     '_repr_fits_vertical_',
     '_repr_html_',
     '_repr_latex_',
     '_reset_cache',
     '_reset_cacher',
     '_sanitize_column',
     '_series',
     '_set_axis',
     '_set_axis_name',
     '_set_axis_nocheck',
     '_set_is_copy',
     '_set_item',
     '_set_item_frame_value',
     '_set_item_mgr',
     '_set_value',
     '_setitem_array',
     '_setitem_frame',
     '_setitem_slice',
     '_slice',
     '_stat_axis',
     '_stat_axis_name',
     '_stat_axis_number',
     '_stat_function',
     '_stat_function_ddof',
     '_take_with_is_copy',
     '_to_dict_of_blocks',
     '_typ',
     '_update_inplace',
     '_validate_dtype',
     '_values',
     '_where',
     'abs',
     'add',
     'add_prefix',
     'add_suffix',
     'agg',
     'aggregate',
     'align',
     'all',
     'any',
     'append',
     'apply',
     'applymap',
     'asfreq',
     'asof',
     'assign',
     'astype',
     'at',
     'at_time',
     'attrs',
     'axes',
     'backfill',
     'between_time',
     'bfill',
     'bool',
     'boxplot',
     'clip',
     'columns',
     'combine',
     'combine_first',
     'compare',
     'convert_dtypes',
     'copy',
     'corr',
     'corrwith',
     'count',
     'cov',
     'cummax',
     'cummin',
     'cumprod',
     'cumsum',
     'describe',
     'diff',
     'div',
     'divide',
     'dot',
     'drop',
     'drop_duplicates',
     'droplevel',
     'dropna',
     'dtypes',
     'duplicated',
     'empty',
     'eq',
     'equals',
     'eval',
     'ewm',
     'expanding',
     'explode',
     'ffill',
     'fillna',
     'filter',
     'first',
     'first_valid_index',
     'flags',
     'floordiv',
     'from_dict',
     'from_records',
     'ge',
     'get',
     'groupby',
     'gt',
     'head',
     'hist',
     'iat',
     'idxmax',
     'idxmin',
     'iloc',
     'index',
     'infer_objects',
     'info',
     'insert',
     'interpolate',
     'isin',
     'isna',
     'isnull',
     'items',
     'iteritems',
     'iterrows',
     'itertuples',
     'join',
     'keys',
     'kurt',
     'kurtosis',
     'last',
     'last_valid_index',
     'le',
     'loc',
     'lookup',
     'lt',
     'mad',
     'mask',
     'max',
     'mean',
     'mean_test_score',
     'median',
     'melt',
     'memory_usage',
     'merge',
     'min',
     'mod',
     'mode',
     'mul',
     'multiply',
     'ndim',
     'ne',
     'nlargest',
     'notna',
     'notnull',
     'nsmallest',
     'nunique',
     'pad',
     'param_C',
     'param_kernel',
     'pct_change',
     'pipe',
     'pivot',
     'pivot_table',
     'plot',
     'pop',
     'pow',
     'prod',
     'product',
     'quantile',
     'query',
     'radd',
     'rank',
     'rdiv',
     'reindex',
     'reindex_like',
     'rename',
     'rename_axis',
     'reorder_levels',
     'replace',
     'resample',
     'reset_index',
     'rfloordiv',
     'rmod',
     'rmul',
     'rolling',
     'round',
     'rpow',
     'rsub',
     'rtruediv',
     'sample',
     'select_dtypes',
     'sem',
     'set_axis',
     'set_flags',
     'set_index',
     'shape',
     'shift',
     'size',
     'skew',
     'slice_shift',
     'sort_index',
     'sort_values',
     'squeeze',
     'stack',
     'std',
     'style',
     'sub',
     'subtract',
     'sum',
     'swapaxes',
     'swaplevel',
     'tail',
     'take',
     'to_clipboard',
     'to_csv',
     'to_dict',
     'to_excel',
     'to_feather',
     'to_gbq',
     'to_hdf',
     'to_html',
     'to_json',
     'to_latex',
     'to_markdown',
     'to_numpy',
     'to_parquet',
     'to_period',
     'to_pickle',
     'to_records',
     'to_sql',
     'to_stata',
     'to_string',
     'to_timestamp',
     'to_xarray',
     'to_xml',
     'transform',
     'transpose',
     'truediv',
     'truncate',
     'tz_convert',
     'tz_localize',
     'unstack',
     'update',
     'value_counts',
     'values',
     'var',
     'where',
     'xs']




```python
dir(clf)
```




    ['__abstractmethods__',
     '__class__',
     '__delattr__',
     '__dict__',
     '__dir__',
     '__doc__',
     '__eq__',
     '__format__',
     '__ge__',
     '__getattribute__',
     '__getstate__',
     '__gt__',
     '__hash__',
     '__init__',
     '__init_subclass__',
     '__le__',
     '__lt__',
     '__module__',
     '__ne__',
     '__new__',
     '__reduce__',
     '__reduce_ex__',
     '__repr__',
     '__setattr__',
     '__setstate__',
     '__sizeof__',
     '__str__',
     '__subclasshook__',
     '__weakref__',
     '_abc_impl',
     '_check_feature_names',
     '_check_n_features',
     '_check_refit_for_multimetric',
     '_estimator_type',
     '_format_results',
     '_get_param_names',
     '_get_tags',
     '_more_tags',
     '_pairwise',
     '_repr_html_',
     '_repr_html_inner',
     '_repr_mimebundle_',
     '_required_parameters',
     '_run_search',
     '_select_best_index',
     '_validate_data',
     'best_estimator_',
     'best_index_',
     'best_params_',
     'best_score_',
     'classes_',
     'cv',
     'cv_results_',
     'decision_function',
     'error_score',
     'estimator',
     'fit',
     'get_params',
     'inverse_transform',
     'multimetric_',
     'n_features_in_',
     'n_jobs',
     'n_splits_',
     'param_grid',
     'pre_dispatch',
     'predict',
     'predict_log_proba',
     'predict_proba',
     'refit',
     'refit_time_',
     'return_train_score',
     'score',
     'score_samples',
     'scorer_',
     'scoring',
     'set_params',
     'transform',
     'verbose']




```python
clf.best_score_
```




    0.9800000000000001




```python
clf.estimator
```




    SVC(gamma='auto')




```python
clf.best_params_
```




    {'C': 1, 'kernel': 'rbf'}




```python
# Randomized Search CV
from sklearn.model_selection import RandomizedSearchCV
```


```python
rs = RandomizedSearchCV(SVC(gamma='auto'),{
    'C':[1,10,20],
    'kernel':['rbf','linear','poly', 'sigmoid']
}, cv=5, return_train_score=False, n_iter=2)
rs.fit(d.data, d.target)
rs.cv_results_
```




    {'mean_fit_time': array([0.00219736, 0.00079875]),
     'std_fit_time': array([0.00040062, 0.00039938]),
     'mean_score_time': array([0.00059943, 0.00059991]),
     'std_score_time': array([0.00048944, 0.00048983]),
     'param_kernel': masked_array(data=['sigmoid', 'rbf'],
                  mask=[False, False],
            fill_value='?',
                 dtype=object),
     'param_C': masked_array(data=[10, 10],
                  mask=[False, False],
            fill_value='?',
                 dtype=object),
     'params': [{'kernel': 'sigmoid', 'C': 10}, {'kernel': 'rbf', 'C': 10}],
     'split0_test_score': array([0.33333333, 0.96666667]),
     'split1_test_score': array([0.1, 1. ]),
     'split2_test_score': array([0.        , 0.96666667]),
     'split3_test_score': array([0.03333333, 0.96666667]),
     'split4_test_score': array([0., 1.]),
     'mean_test_score': array([0.09333333, 0.98      ]),
     'std_test_score': array([0.12543258, 0.01632993]),
     'rank_test_score': array([2, 1])}




```python
df4 = pd.DataFrame(rs.cv_results_)[['param_kernel','param_C','mean_test_score']]
df4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>param_kernel</th>
      <th>param_C</th>
      <th>mean_test_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sigmoid</td>
      <td>10</td>
      <td>0.093333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>rbf</td>
      <td>10</td>
      <td>0.980000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# selecting best model with best parameters
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
```


```python
model_params = {
    'svm':{
        'model':SVC(gamma='auto'),
        'params':{
            'C':[1,10,20],
            'kernel':['rbf','linear']
        }
    },
    'random_forest':{
        'model':RandomForestClassifier(),
        'params':{
            'n_estimators':[1,5,10]
        }
    },
    'logistic_regression':{
        'model':LogisticRegression(solver='liblinear',multi_class='auto'),
        'params':{
            'C':[1,5,10]
        }
    },
    'GaussianNB':{
        'model':GaussianNB(),
        'params':{
             
            'var_smoothing':[1e-09]
        }
    },
    'MultinomialNB':{
        'model':MultinomialNB(),
        'params':{
            'alpha':[1.0], 
            'fit_prior':[True] 
            
        }
    }
    
}
```


```python
scores = []
for model_name,mp in model_params.items():
    clf = GridSearchCV(mp['model'], mp['params'], cv=5, return_train_score=False)
    clf.fit(d.data, d.target)
    scores.append({
        'model':model_name,
        'best_score': clf.best_score_,
        'best_params': clf.best_params_
        
    })
```


```python
pd.DataFrame(scores)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>best_score</th>
      <th>best_params</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>svm</td>
      <td>0.980000</td>
      <td>{'C': 1, 'kernel': 'rbf'}</td>
    </tr>
    <tr>
      <th>1</th>
      <td>random_forest</td>
      <td>0.960000</td>
      <td>{'n_estimators': 5}</td>
    </tr>
    <tr>
      <th>2</th>
      <td>logistic_regression</td>
      <td>0.966667</td>
      <td>{'C': 5}</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GaussianNB</td>
      <td>0.953333</td>
      <td>{'var_smoothing': 1e-09}</td>
    </tr>
    <tr>
      <th>4</th>
      <td>MultinomialNB</td>
      <td>0.953333</td>
      <td>{'alpha': 1.0, 'fit_prior': True}</td>
    </tr>
  </tbody>
</table>
</div>



---

## L1 and L2 Regularization- Lasso, Ridge Regression


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
import warnings
warnings.filterwarnings('ignore')
```


```python
d = pd.read_csv('D:/ds/ML/16_regularization/Melbourne_housing_FULL.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Suburb</th>
      <th>Address</th>
      <th>Rooms</th>
      <th>Type</th>
      <th>Price</th>
      <th>Method</th>
      <th>SellerG</th>
      <th>Date</th>
      <th>Distance</th>
      <th>Postcode</th>
      <th>...</th>
      <th>Bathroom</th>
      <th>Car</th>
      <th>Landsize</th>
      <th>BuildingArea</th>
      <th>YearBuilt</th>
      <th>CouncilArea</th>
      <th>Lattitude</th>
      <th>Longtitude</th>
      <th>Regionname</th>
      <th>Propertycount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Abbotsford</td>
      <td>68 Studley St</td>
      <td>2</td>
      <td>h</td>
      <td>NaN</td>
      <td>SS</td>
      <td>Jellis</td>
      <td>3/09/2016</td>
      <td>2.5</td>
      <td>3067.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>126.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yarra City Council</td>
      <td>-37.8014</td>
      <td>144.9958</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Abbotsford</td>
      <td>85 Turner St</td>
      <td>2</td>
      <td>h</td>
      <td>1480000.0</td>
      <td>S</td>
      <td>Biggin</td>
      <td>3/12/2016</td>
      <td>2.5</td>
      <td>3067.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>202.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yarra City Council</td>
      <td>-37.7996</td>
      <td>144.9984</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Abbotsford</td>
      <td>25 Bloomburg St</td>
      <td>2</td>
      <td>h</td>
      <td>1035000.0</td>
      <td>S</td>
      <td>Biggin</td>
      <td>4/02/2016</td>
      <td>2.5</td>
      <td>3067.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>156.0</td>
      <td>79.0</td>
      <td>1900.0</td>
      <td>Yarra City Council</td>
      <td>-37.8079</td>
      <td>144.9934</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Abbotsford</td>
      <td>18/659 Victoria St</td>
      <td>3</td>
      <td>u</td>
      <td>NaN</td>
      <td>VB</td>
      <td>Rounds</td>
      <td>4/02/2016</td>
      <td>2.5</td>
      <td>3067.0</td>
      <td>...</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yarra City Council</td>
      <td>-37.8114</td>
      <td>145.0116</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Abbotsford</td>
      <td>5 Charles St</td>
      <td>3</td>
      <td>h</td>
      <td>1465000.0</td>
      <td>SP</td>
      <td>Biggin</td>
      <td>4/03/2017</td>
      <td>2.5</td>
      <td>3067.0</td>
      <td>...</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>134.0</td>
      <td>150.0</td>
      <td>1900.0</td>
      <td>Yarra City Council</td>
      <td>-37.8093</td>
      <td>144.9944</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
d.nunique()
```




    Suburb             351
    Address          34009
    Rooms               12
    Type                 3
    Price             2871
    Method               9
    SellerG            388
    Date                78
    Distance           215
    Postcode           211
    Bedroom2            15
    Bathroom            11
    Car                 15
    Landsize          1684
    BuildingArea       740
    YearBuilt          160
    CouncilArea         33
    Lattitude        13402
    Longtitude       14524
    Regionname           8
    Propertycount      342
    dtype: int64




```python
d.columns
```




    Index(['Suburb', 'Address', 'Rooms', 'Type', 'Price', 'Method', 'SellerG',
           'Date', 'Distance', 'Postcode', 'Bedroom2', 'Bathroom', 'Car',
           'Landsize', 'BuildingArea', 'YearBuilt', 'CouncilArea', 'Lattitude',
           'Longtitude', 'Regionname', 'Propertycount'],
          dtype='object')




```python
d.shape
```




    (34857, 21)




```python
d = d[['Suburb','Rooms', 'Type','Method', 'SellerG','Regionname', 'Propertycount','Distance','Bedroom2', 'Bathroom','Car',
       'Landsize','CouncilArea','BuildingArea','Price']]
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Suburb</th>
      <th>Rooms</th>
      <th>Type</th>
      <th>Method</th>
      <th>SellerG</th>
      <th>Regionname</th>
      <th>Propertycount</th>
      <th>Distance</th>
      <th>Bedroom2</th>
      <th>Bathroom</th>
      <th>Car</th>
      <th>Landsize</th>
      <th>CouncilArea</th>
      <th>BuildingArea</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Abbotsford</td>
      <td>2</td>
      <td>h</td>
      <td>SS</td>
      <td>Jellis</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>126.0</td>
      <td>Yarra City Council</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Abbotsford</td>
      <td>2</td>
      <td>h</td>
      <td>S</td>
      <td>Biggin</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>202.0</td>
      <td>Yarra City Council</td>
      <td>NaN</td>
      <td>1480000.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Abbotsford</td>
      <td>2</td>
      <td>h</td>
      <td>S</td>
      <td>Biggin</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>156.0</td>
      <td>Yarra City Council</td>
      <td>79.0</td>
      <td>1035000.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Abbotsford</td>
      <td>3</td>
      <td>u</td>
      <td>VB</td>
      <td>Rounds</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>Yarra City Council</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Abbotsford</td>
      <td>3</td>
      <td>h</td>
      <td>SP</td>
      <td>Biggin</td>
      <td>Northern Metropolitan</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>134.0</td>
      <td>Yarra City Council</td>
      <td>150.0</td>
      <td>1465000.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.shape
```




    (34857, 15)




```python
d.isnull().sum()
```




    Suburb               0
    Rooms                0
    Type                 0
    Method               0
    SellerG              0
    Regionname           3
    Propertycount        3
    Distance             1
    Bedroom2          8217
    Bathroom          8226
    Car               8728
    Landsize         11810
    CouncilArea          3
    BuildingArea     21115
    Price             7610
    dtype: int64




```python
d1 = ['Propertycount','Distance','Bedroom2','Bathroom','Car']
d[d1] = d[d1].fillna(0)
```


```python
d.isnull().sum()
```




    Suburb               0
    Rooms                0
    Type                 0
    Method               0
    SellerG              0
    Regionname           3
    Propertycount        0
    Distance             0
    Bedroom2             0
    Bathroom             0
    Car                  0
    Landsize         11810
    CouncilArea          3
    BuildingArea     21115
    Price             7610
    dtype: int64




```python
d2 = ['Landsize', 'BuildingArea']
d[d2] = d[d2].fillna(d[d2].mean())
```


```python
d.isnull().sum()
```




    Suburb           0
    Rooms            0
    Type             0
    Method           0
    SellerG          0
    Regionname       0
    Propertycount    0
    Distance         0
    Bedroom2         0
    Bathroom         0
    Car              0
    Landsize         0
    CouncilArea      0
    BuildingArea     0
    Price            0
    dtype: int64




```python
d.dropna(inplace=True)
```


```python
d.isnull().sum()
```




    Suburb           0
    Rooms            0
    Type             0
    Method           0
    SellerG          0
    Regionname       0
    Propertycount    0
    Distance         0
    Bedroom2         0
    Bathroom         0
    Car              0
    Landsize         0
    CouncilArea      0
    BuildingArea     0
    Price            0
    dtype: int64




```python
d = pd.get_dummies(d, drop_first=True)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rooms</th>
      <th>Propertycount</th>
      <th>Distance</th>
      <th>Bedroom2</th>
      <th>Bathroom</th>
      <th>Car</th>
      <th>Landsize</th>
      <th>BuildingArea</th>
      <th>Price</th>
      <th>Suburb_Aberfeldie</th>
      <th>...</th>
      <th>CouncilArea_Moorabool Shire Council</th>
      <th>CouncilArea_Moreland City Council</th>
      <th>CouncilArea_Nillumbik Shire Council</th>
      <th>CouncilArea_Port Phillip City Council</th>
      <th>CouncilArea_Stonnington City Council</th>
      <th>CouncilArea_Whitehorse City Council</th>
      <th>CouncilArea_Whittlesea City Council</th>
      <th>CouncilArea_Wyndham City Council</th>
      <th>CouncilArea_Yarra City Council</th>
      <th>CouncilArea_Yarra Ranges Shire Council</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>202.0</td>
      <td>160.2564</td>
      <td>1480000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>156.0</td>
      <td>79.0000</td>
      <td>1035000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>134.0</td>
      <td>150.0000</td>
      <td>1465000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>94.0</td>
      <td>160.2564</td>
      <td>850000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>4</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0</td>
      <td>142.0000</td>
      <td>1600000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 745 columns</p>
</div>




```python
X = d.drop('Price', axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rooms</th>
      <th>Propertycount</th>
      <th>Distance</th>
      <th>Bedroom2</th>
      <th>Bathroom</th>
      <th>Car</th>
      <th>Landsize</th>
      <th>BuildingArea</th>
      <th>Suburb_Aberfeldie</th>
      <th>Suburb_Airport West</th>
      <th>...</th>
      <th>CouncilArea_Moorabool Shire Council</th>
      <th>CouncilArea_Moreland City Council</th>
      <th>CouncilArea_Nillumbik Shire Council</th>
      <th>CouncilArea_Port Phillip City Council</th>
      <th>CouncilArea_Stonnington City Council</th>
      <th>CouncilArea_Whitehorse City Council</th>
      <th>CouncilArea_Whittlesea City Council</th>
      <th>CouncilArea_Wyndham City Council</th>
      <th>CouncilArea_Yarra City Council</th>
      <th>CouncilArea_Yarra Ranges Shire Council</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>202.0</td>
      <td>160.2564</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>156.0</td>
      <td>79.0000</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>134.0</td>
      <td>150.0000</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>94.0</td>
      <td>160.2564</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>4</td>
      <td>4019.0</td>
      <td>2.5</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>120.0</td>
      <td>142.0000</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 744 columns</p>
</div>




```python
y = d['Price']
```


```python
y.head()
```




    1    1480000.0
    2    1035000.0
    4    1465000.0
    5     850000.0
    6    1600000.0
    Name: Price, dtype: float64




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)
```


```python
from sklearn.linear_model import LinearRegression
reg = LinearRegression().fit(X_train, y_train)
```


```python
reg.score(X_test, y_test)
```




    0.6738662013473842




```python
reg.score(X_train, y_train)
```




    0.6795975642174452




```python
from sklearn.linear_model import Lasso
```


```python
las_reg = Lasso(alpha=50, max_iter=100, tol=0.1 )
```


```python
las_reg.fit(X_train, y_train)
```




    Lasso(alpha=50, max_iter=100, tol=0.1)




```python
las_reg.score(X_test, y_test)
```




    0.6750607190953164




```python
from sklearn.linear_model import Ridge
```


```python
rd = Ridge(alpha=50, max_iter=100, tol=0.1)
```


```python
rd.fit(X_train, y_train)
```




    Ridge(alpha=50, max_iter=100, tol=0.1)




```python
rd.score(X_test, y_test)
```




    0.6684420991703934



---

## KNN


```python
import pandas as pd
```


```python
from sklearn.datasets import load_iris
```


```python
d = load_iris()
```


```python
dir(d)
```




    ['DESCR',
     'data',
     'data_module',
     'feature_names',
     'filename',
     'frame',
     'target',
     'target_names']




```python
d1 = pd.DataFrame(d.data, columns=d.feature_names)
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1['species'] = d.target
```


```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1['flower_name'] = d1.species.apply(lambda x: d.target_names[x])
```


```python
d1.flower_name.unique()
```




    array(['setosa', 'versicolor', 'virginica'], dtype=object)




```python
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>species</th>
      <th>flower_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
df0 = d1[d1.flower_name=='setosa']
```


```python
df0.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal length (cm)</th>
      <th>sepal width (cm)</th>
      <th>petal length (cm)</th>
      <th>petal width (cm)</th>
      <th>species</th>
      <th>flower_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1 = d1[d1.flower_name=='versicolor']
```


```python
df2 = d1[d1.flower_name=='virginica']
```


```python
df2.shape
```




    (50, 6)




```python
import matplotlib.pyplot as plt
```


```python
plt.scatter(df0['sepal length (cm)'], df0['sepal width (cm)'], color='green', marker='+')
plt.scatter(df1['sepal length (cm)'], df1['sepal width (cm)'], color='blue', marker='o')
```




    <matplotlib.collections.PathCollection at 0x1b74c9b6fe0>




    
![png](output_522_1.png)
    



```python
from sklearn.model_selection import train_test_split
```


```python
X = d1.drop(['species','flower_name'], axis=1)
```


```python
y = d1.species
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=0)
```


```python
from sklearn.neighbors import KNeighborsClassifier
```


```python
knn = KNeighborsClassifier(n_neighbors=3)
```


```python
knn.fit(X_train, y_train)
```




    KNeighborsClassifier(n_neighbors=3)




```python
knn.score(X_test, y_test)
```




    0.9666666666666667




```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, y_pred = knn.predict(X_test))
```


```python
cm
```




    array([[11,  0,  0],
           [ 0, 12,  1],
           [ 0,  0,  6]], dtype=int64)




```python
import seaborn as sns
```


```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_535_1.png)
    



```python
from sklearn.metrics import classification_report
```


```python
print(classification_report(y_test, y_pred = knn.predict(X_test)))
```

                  precision    recall  f1-score   support
    
               0       1.00      1.00      1.00        11
               1       1.00      0.92      0.96        13
               2       0.86      1.00      0.92         6
    
        accuracy                           0.97        30
       macro avg       0.95      0.97      0.96        30
    weighted avg       0.97      0.97      0.97        30
    
    


```python
from sklearn.datasets import load_digits
```


```python
d = load_digits()
```


```python
dir(d)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'images', 'target', 'target_names']




```python
X = d.data
```


```python
y = d.target
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X , y , test_size=0.2)
```


```python
from sklearn.neighbors import KNeighborsClassifier
```


```python
knn = KNeighborsClassifier(n_neighbors=3)
```


```python
knn.fit(X_train, y_train)
```




    KNeighborsClassifier(n_neighbors=3)




```python
knn.score(X_test, y_test)
```




    0.9833333333333333




```python
from sklearn.metrics import confusion_matrix
```


```python
cm = confusion_matrix(y_test, knn.predict(X_test))
```


```python
cm
```




    array([[44,  0,  0,  0,  0,  0,  0,  0,  0,  0],
           [ 0, 47,  0,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0, 31,  0,  0,  0,  0,  0,  0,  0],
           [ 0,  0,  0, 32,  0,  0,  0,  1,  0,  0],
           [ 0,  0,  0,  0, 32,  0,  0,  0,  0,  0],
           [ 0,  0,  0,  0,  0, 37,  0,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0, 39,  0,  0,  0],
           [ 0,  0,  0,  0,  0,  0,  0, 22,  0,  0],
           [ 0,  2,  0,  0,  0,  0,  0,  0, 32,  0],
           [ 0,  1,  0,  1,  0,  0,  0,  0,  1, 38]], dtype=int64)




```python
sns.heatmap(cm, annot=True)
```




    <AxesSubplot:>




    
![png](output_552_1.png)
    



```python
from sklearn.metrics import classification_report
```


```python
print(classification_report(y_test, knn.predict(X_test)))
```

                  precision    recall  f1-score   support
    
               0       1.00      1.00      1.00        44
               1       0.94      1.00      0.97        47
               2       1.00      1.00      1.00        31
               3       0.97      0.97      0.97        33
               4       1.00      1.00      1.00        32
               5       1.00      1.00      1.00        37
               6       1.00      1.00      1.00        39
               7       0.96      1.00      0.98        22
               8       0.97      0.94      0.96        34
               9       1.00      0.93      0.96        41
    
        accuracy                           0.98       360
       macro avg       0.98      0.98      0.98       360
    weighted avg       0.98      0.98      0.98       360
    
    

---

## PCA


```python
import pandas as pd
```


```python
from sklearn.datasets import load_digits
```


```python
df = load_digits()
```


```python
dir(df)
```




    ['DESCR', 'data', 'feature_names', 'frame', 'images', 'target', 'target_names']




```python
X = df.data
```


```python
y = df.target
```


```python
from sklearn.preprocessing import StandardScaler
```


```python
scaler = StandardScaler()
```


```python
X_scaled = scaler.fit_transform(X)
```


```python
print(X_scaled)
```

    [[ 0.         -0.33501649 -0.04308102 ... -1.14664746 -0.5056698
      -0.19600752]
     [ 0.         -0.33501649 -1.09493684 ...  0.54856067 -0.5056698
      -0.19600752]
     [ 0.         -0.33501649 -1.09493684 ...  1.56568555  1.6951369
      -0.19600752]
     ...
     [ 0.         -0.33501649 -0.88456568 ... -0.12952258 -0.5056698
      -0.19600752]
     [ 0.         -0.33501649 -0.67419451 ...  0.8876023  -0.5056698
      -0.19600752]
     [ 0.         -0.33501649  1.00877481 ...  0.8876023  -0.26113572
      -0.19600752]]
    


```python
X_scaled.mean(axis=0)
```




    array([ 0.00000000e+00, -2.56086502e-16, -2.34771702e-16, -3.05326777e-16,
            1.39689163e-16, -3.16941798e-16, -9.59598443e-16,  6.06946633e-16,
           -4.62368967e-16,  7.55084971e-17, -5.33796713e-17,  5.71483749e-17,
            4.52862258e-17, -1.49512505e-17,  8.96580775e-16, -2.17719863e-16,
           -6.87973761e-16, -7.70421876e-17,  2.59978769e-16,  2.32547550e-16,
            1.05878949e-16, -1.40863021e-16, -1.15408826e-16, -2.26477465e-16,
            4.51109193e-16,  3.79341646e-17, -7.71657517e-17, -9.60092699e-17,
           -8.72980041e-17, -1.50624582e-16, -1.05597840e-15, -2.52140175e-16,
            0.00000000e+00,  3.42148865e-16,  1.21710593e-16, -1.07871419e-16,
           -2.00606242e-16, -1.09354188e-17, -7.12964591e-17,  0.00000000e+00,
            3.00716294e-16, -1.74657790e-16,  4.03436636e-16,  1.92111213e-16,
            2.61337974e-17,  5.38739275e-17,  4.71396866e-17,  8.63759074e-16,
            2.62048467e-16,  3.33128689e-16,  8.36528645e-17,  1.98775949e-16,
            4.61017485e-16,  5.01670059e-17,  4.71582212e-16, -4.92032063e-16,
            2.25353805e-16,  3.44125890e-16,  5.95269830e-17, -6.11460582e-16,
           -5.19092591e-16,  1.69529882e-16,  1.78797186e-16, -6.83896148e-16])




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2)
```


```python
from sklearn.linear_model import LogisticRegression
```


```python
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.9666666666666667




```python
from sklearn.decomposition import PCA
```


```python
pca = PCA(0.95)
```


```python
X_pca = pca.fit_transform(X)
```


```python
X_pca.shape
```




    (1797, 29)




```python
pca.explained_variance_ratio_
```




    array([0.14890594, 0.13618771, 0.11794594, 0.08409979, 0.05782415,
           0.0491691 , 0.04315987, 0.03661373, 0.03353248, 0.03078806,
           0.02372341, 0.02272697, 0.01821863, 0.01773855, 0.01467101,
           0.01409716, 0.01318589, 0.01248138, 0.01017718, 0.00905617,
           0.00889538, 0.00797123, 0.00767493, 0.00722904, 0.00695889,
           0.00596081, 0.00575615, 0.00515158, 0.0048954 ])




```python
pca.n_components_
```




    29




```python
X_train, X_test, y_train, y_test = train_test_split(X_pca , y, test_size = 0.2, random_state=1)
```


```python
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.9638888888888889




```python
import pandas as pd
```


```python
d = pd.read_csv('D:/ds/ML/18_PCA/Exercise/heart.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Sex</th>
      <th>ChestPainType</th>
      <th>RestingBP</th>
      <th>Cholesterol</th>
      <th>FastingBS</th>
      <th>RestingECG</th>
      <th>MaxHR</th>
      <th>ExerciseAngina</th>
      <th>Oldpeak</th>
      <th>ST_Slope</th>
      <th>HeartDisease</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>40</td>
      <td>M</td>
      <td>ATA</td>
      <td>140</td>
      <td>289</td>
      <td>0</td>
      <td>Normal</td>
      <td>172</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>F</td>
      <td>NAP</td>
      <td>160</td>
      <td>180</td>
      <td>0</td>
      <td>Normal</td>
      <td>156</td>
      <td>N</td>
      <td>1.0</td>
      <td>Flat</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>M</td>
      <td>ATA</td>
      <td>130</td>
      <td>283</td>
      <td>0</td>
      <td>ST</td>
      <td>98</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>48</td>
      <td>F</td>
      <td>ASY</td>
      <td>138</td>
      <td>214</td>
      <td>0</td>
      <td>Normal</td>
      <td>108</td>
      <td>Y</td>
      <td>1.5</td>
      <td>Flat</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>54</td>
      <td>M</td>
      <td>NAP</td>
      <td>150</td>
      <td>195</td>
      <td>0</td>
      <td>Normal</td>
      <td>122</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d = pd.get_dummies(d, drop_first=True)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>RestingBP</th>
      <th>Cholesterol</th>
      <th>FastingBS</th>
      <th>MaxHR</th>
      <th>Oldpeak</th>
      <th>HeartDisease</th>
      <th>Sex_M</th>
      <th>ChestPainType_ATA</th>
      <th>ChestPainType_NAP</th>
      <th>ChestPainType_TA</th>
      <th>RestingECG_Normal</th>
      <th>RestingECG_ST</th>
      <th>ExerciseAngina_Y</th>
      <th>ST_Slope_Flat</th>
      <th>ST_Slope_Up</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>40</td>
      <td>140</td>
      <td>289</td>
      <td>0</td>
      <td>172</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>160</td>
      <td>180</td>
      <td>0</td>
      <td>156</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>130</td>
      <td>283</td>
      <td>0</td>
      <td>98</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>48</td>
      <td>138</td>
      <td>214</td>
      <td>0</td>
      <td>108</td>
      <td>1.5</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>54</td>
      <td>150</td>
      <td>195</td>
      <td>0</td>
      <td>122</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = d.drop(['HeartDisease'], axis=1)
```


```python
y = d['HeartDisease']
```


```python
X.shape
```




    (918, 15)




```python
X.isnull().sum()
```




    Age                  0
    RestingBP            0
    Cholesterol          0
    FastingBS            0
    MaxHR                0
    Oldpeak              0
    Sex_M                0
    ChestPainType_ATA    0
    ChestPainType_NAP    0
    ChestPainType_TA     0
    RestingECG_Normal    0
    RestingECG_ST        0
    ExerciseAngina_Y     0
    ST_Slope_Flat        0
    ST_Slope_Up          0
    dtype: int64




```python
y.isnull().sum()
```




    0




```python
from sklearn.preprocessing import StandardScaler
```


```python
scaler = StandardScaler()
```


```python
X_scaled = scaler.fit_transform(X)
```


```python
print(X_scaled)
```

    [[-1.4331398   0.41090889  0.82507026 ... -0.8235563  -1.00218103
       1.15067399]
     [-0.47848359  1.49175234 -0.17196105 ... -0.8235563   0.99782372
      -0.86905588]
     [-1.75135854 -0.12951283  0.7701878  ... -0.8235563  -1.00218103
       1.15067399]
     ...
     [ 0.37009972 -0.12951283 -0.62016778 ...  1.21424608  0.99782372
      -0.86905588]
     [ 0.37009972 -0.12951283  0.34027522 ... -0.8235563   0.99782372
      -0.86905588]
     [-1.64528563  0.30282455 -0.21769643 ... -0.8235563  -1.00218103
       1.15067399]]
    


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size = 0.2, random_state=1)
```


```python
from sklearn.linear_model import LogisticRegression
```


```python
model = LogisticRegression()
```


```python
model.fit(X_train, y_train)
```




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.8967391304347826




```python
from sklearn.decomposition import PCA
```


```python
pca = PCA(1)
```


```python
X_pca = pca.fit_transform(X)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_pca , y, test_size=0.2)
```


```python
model.fit(X_train, y_train)
```




    LogisticRegression()




```python
model.score(X_test, y_test)
```




    0.4945652173913043



---

## Ensemble-Bagging


```python
import pandas as pd
```


```python
d = pd.read_csv('D:/ds/ML/19_Bagging/diabetes.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pregnancies</th>
      <th>Glucose</th>
      <th>BloodPressure</th>
      <th>SkinThickness</th>
      <th>Insulin</th>
      <th>BMI</th>
      <th>DiabetesPedigreeFunction</th>
      <th>Age</th>
      <th>Outcome</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6</td>
      <td>148</td>
      <td>72</td>
      <td>35</td>
      <td>0</td>
      <td>33.6</td>
      <td>0.627</td>
      <td>50</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>85</td>
      <td>66</td>
      <td>29</td>
      <td>0</td>
      <td>26.6</td>
      <td>0.351</td>
      <td>31</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8</td>
      <td>183</td>
      <td>64</td>
      <td>0</td>
      <td>0</td>
      <td>23.3</td>
      <td>0.672</td>
      <td>32</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>89</td>
      <td>66</td>
      <td>23</td>
      <td>94</td>
      <td>28.1</td>
      <td>0.167</td>
      <td>21</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>137</td>
      <td>40</td>
      <td>35</td>
      <td>168</td>
      <td>43.1</td>
      <td>2.288</td>
      <td>33</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pregnancies</th>
      <th>Glucose</th>
      <th>BloodPressure</th>
      <th>SkinThickness</th>
      <th>Insulin</th>
      <th>BMI</th>
      <th>DiabetesPedigreeFunction</th>
      <th>Age</th>
      <th>Outcome</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
      <td>768.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3.845052</td>
      <td>120.894531</td>
      <td>69.105469</td>
      <td>20.536458</td>
      <td>79.799479</td>
      <td>31.992578</td>
      <td>0.471876</td>
      <td>33.240885</td>
      <td>0.348958</td>
    </tr>
    <tr>
      <th>std</th>
      <td>3.369578</td>
      <td>31.972618</td>
      <td>19.355807</td>
      <td>15.952218</td>
      <td>115.244002</td>
      <td>7.884160</td>
      <td>0.331329</td>
      <td>11.760232</td>
      <td>0.476951</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.078000</td>
      <td>21.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>99.000000</td>
      <td>62.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>27.300000</td>
      <td>0.243750</td>
      <td>24.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3.000000</td>
      <td>117.000000</td>
      <td>72.000000</td>
      <td>23.000000</td>
      <td>30.500000</td>
      <td>32.000000</td>
      <td>0.372500</td>
      <td>29.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.000000</td>
      <td>140.250000</td>
      <td>80.000000</td>
      <td>32.000000</td>
      <td>127.250000</td>
      <td>36.600000</td>
      <td>0.626250</td>
      <td>41.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>17.000000</td>
      <td>199.000000</td>
      <td>122.000000</td>
      <td>99.000000</td>
      <td>846.000000</td>
      <td>67.100000</td>
      <td>2.420000</td>
      <td>81.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.Outcome.value_counts()
```




    0    500
    1    268
    Name: Outcome, dtype: int64




```python
X = d.drop('Outcome', axis=1)
```


```python
y = d.Outcome
```


```python
from sklearn.preprocessing import StandardScaler
```


```python
scaler = StandardScaler()
```


```python
X_scaled = scaler.fit_transform(X)
```


```python
X_scaled
```




    array([[ 0.63994726,  0.84832379,  0.14964075, ...,  0.20401277,
             0.46849198,  1.4259954 ],
           [-0.84488505, -1.12339636, -0.16054575, ..., -0.68442195,
            -0.36506078, -0.19067191],
           [ 1.23388019,  1.94372388, -0.26394125, ..., -1.10325546,
             0.60439732, -0.10558415],
           ...,
           [ 0.3429808 ,  0.00330087,  0.14964075, ..., -0.73518964,
            -0.68519336, -0.27575966],
           [-0.84488505,  0.1597866 , -0.47073225, ..., -0.24020459,
            -0.37110101,  1.17073215],
           [-0.84488505, -0.8730192 ,  0.04624525, ..., -0.20212881,
            -0.47378505, -0.87137393]])




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, stratify=y, random_state=0)
```


```python
X_train.shape
```




    (576, 8)




```python
X.shape
```




    (768, 8)




```python
y.value_counts()
```




    0    500
    1    268
    Name: Outcome, dtype: int64




```python
268/500
```




    0.536




```python
y_train.value_counts()
```




    0    375
    1    201
    Name: Outcome, dtype: int64




```python
201/375
```




    0.536




```python
from sklearn.tree import DecisionTreeClassifier
```


```python
model = DecisionTreeClassifier()
```


```python
from sklearn.model_selection import cross_val_score
```


```python
scores=cross_val_score(model, X, y, cv=5)
```


```python
scores.mean()
```




    0.7136575842458196




```python
from sklearn.ensemble import BaggingClassifier
```


```python
bc = BaggingClassifier(model, n_estimators=100, max_samples=0.8, oob_score=True, random_state=0)
```


```python
bc.fit(X_train, y_train)
```




    BaggingClassifier(base_estimator=DecisionTreeClassifier(), max_samples=0.8,
                      n_estimators=100, oob_score=True, random_state=0)




```python
bc.score(X_test, y_test)
```




    0.7760416666666666



---


```python
import pandas as pd
```


```python
df = pd.read_csv('D:/ds/ML/18_PCA/Exercise/heart.csv')
```


```python
df[df.Cholesterol>(df.Cholesterol.mean()+3*df.Cholesterol.std())]

df.shape
df1 = df[df.Cholesterol<=(df.Cholesterol.mean()+3*df.Cholesterol.std())]
df1.shape
df[df.MaxHR>(df.MaxHR.mean()+3*df.MaxHR.std())]
df[df.FastingBS>(df.FastingBS.mean()+3*df.FastingBS.std())]
df[df.Oldpeak>(df.Oldpeak.mean()+3*df.Oldpeak.std())]
df2 = df1[df1.Oldpeak<=(df1.Oldpeak.mean()+3*df1.Oldpeak.std())]
df2.shape
df[df.RestingBP>(df.RestingBP.mean()+3*df.RestingBP.std())]
df3 = df2[df2.RestingBP<=(df2.RestingBP.mean()+3*df2.RestingBP.std())]
df3.shape
```




    (902, 12)




```python
df3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Sex</th>
      <th>ChestPainType</th>
      <th>RestingBP</th>
      <th>Cholesterol</th>
      <th>FastingBS</th>
      <th>RestingECG</th>
      <th>MaxHR</th>
      <th>ExerciseAngina</th>
      <th>Oldpeak</th>
      <th>ST_Slope</th>
      <th>HeartDisease</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>40</td>
      <td>M</td>
      <td>ATA</td>
      <td>140</td>
      <td>289</td>
      <td>0</td>
      <td>Normal</td>
      <td>172</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>F</td>
      <td>NAP</td>
      <td>160</td>
      <td>180</td>
      <td>0</td>
      <td>Normal</td>
      <td>156</td>
      <td>N</td>
      <td>1.0</td>
      <td>Flat</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>M</td>
      <td>ATA</td>
      <td>130</td>
      <td>283</td>
      <td>0</td>
      <td>ST</td>
      <td>98</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>48</td>
      <td>F</td>
      <td>ASY</td>
      <td>138</td>
      <td>214</td>
      <td>0</td>
      <td>Normal</td>
      <td>108</td>
      <td>Y</td>
      <td>1.5</td>
      <td>Flat</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>54</td>
      <td>M</td>
      <td>NAP</td>
      <td>150</td>
      <td>195</td>
      <td>0</td>
      <td>Normal</td>
      <td>122</td>
      <td>N</td>
      <td>0.0</td>
      <td>Up</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d = pd.get_dummies(df3, drop_first=True)
```


```python
d.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>RestingBP</th>
      <th>Cholesterol</th>
      <th>FastingBS</th>
      <th>MaxHR</th>
      <th>Oldpeak</th>
      <th>HeartDisease</th>
      <th>Sex_M</th>
      <th>ChestPainType_ATA</th>
      <th>ChestPainType_NAP</th>
      <th>ChestPainType_TA</th>
      <th>RestingECG_Normal</th>
      <th>RestingECG_ST</th>
      <th>ExerciseAngina_Y</th>
      <th>ST_Slope_Flat</th>
      <th>ST_Slope_Up</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
      <td>902.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>53.487805</td>
      <td>131.854767</td>
      <td>197.347007</td>
      <td>0.232816</td>
      <td>136.848115</td>
      <td>0.857428</td>
      <td>0.548780</td>
      <td>0.790466</td>
      <td>0.189579</td>
      <td>0.222838</td>
      <td>0.049889</td>
      <td>0.604213</td>
      <td>0.194013</td>
      <td>0.402439</td>
      <td>0.501109</td>
      <td>0.435698</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.444115</td>
      <td>17.682612</td>
      <td>107.585613</td>
      <td>0.422860</td>
      <td>25.451226</td>
      <td>1.013157</td>
      <td>0.497891</td>
      <td>0.407202</td>
      <td>0.392185</td>
      <td>0.416381</td>
      <td>0.217837</td>
      <td>0.489290</td>
      <td>0.395659</td>
      <td>0.490662</td>
      <td>0.500276</td>
      <td>0.496123</td>
    </tr>
    <tr>
      <th>min</th>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>60.000000</td>
      <td>-2.600000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>47.000000</td>
      <td>120.000000</td>
      <td>173.000000</td>
      <td>0.000000</td>
      <td>120.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>54.000000</td>
      <td>130.000000</td>
      <td>222.000000</td>
      <td>0.000000</td>
      <td>138.000000</td>
      <td>0.500000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>60.000000</td>
      <td>140.000000</td>
      <td>266.000000</td>
      <td>0.000000</td>
      <td>156.000000</td>
      <td>1.500000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>77.000000</td>
      <td>185.000000</td>
      <td>518.000000</td>
      <td>1.000000</td>
      <td>202.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# checking outliers
import matplotlib.pyplot as plt
import seaborn as sns
sns.boxplot(d.Cholesterol)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='Cholesterol'>




    
![png](output_647_2.png)
    



```python
import matplotlib.pyplot as plt
import seaborn as sns
sns.boxplot(d.RestingBP)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='RestingBP'>




    
![png](output_648_2.png)
    



```python
sns.boxplot(d.MaxHR)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='MaxHR'>




    
![png](output_649_2.png)
    



```python
sns.boxplot(d.Oldpeak)
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='Oldpeak'>




    
![png](output_650_2.png)
    



```python
d.shape
```




    (902, 16)




```python
X = d.drop(['HeartDisease'], axis=1)
```


```python
y = d.HeartDisease
```


```python
from sklearn.preprocessing import StandardScaler
```


```python
scaler = StandardScaler()
```


```python
X_scaled = scaler.fit_transform(X)
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test =  train_test_split(X_scaled, y, stratify=y, random_state=1 )
```


```python
y.value_counts()
```




    1    495
    0    407
    Name: HeartDisease, dtype: int64




```python
495/407
```




    1.2162162162162162




```python
y_train.value_counts()
```




    1    371
    0    305
    Name: HeartDisease, dtype: int64




```python
371/305
```




    1.2163934426229508




```python
from sklearn.svm import SVC
```


```python
svc = SVC()
```


```python
svc.fit(X_train, y_train)
```




    SVC()




```python
svc.score(X_test, y_test)
```




    0.8539823008849557




```python
from sklearn.ensemble import BaggingClassifier
```


```python
bc = BaggingClassifier(svc, n_estimators=100, max_samples=0.8, oob_score=True, random_state=0)
```


```python
bc.fit(X_train, y_train)
```




    BaggingClassifier(base_estimator=SVC(), max_samples=0.8, n_estimators=100,
                      oob_score=True, random_state=0)




```python
bc.score(X_test, y_test)
```




    0.8628318584070797




```python
bc.oob_score_
```




    0.8801775147928994




```python
from sklearn.model_selection import cross_val_score
```


```python
scores = cross_val_score(bc, X,y,cv=5)
```


```python
scores
```




    array([0.63535912, 0.79558011, 0.68333333, 0.70555556, 0.60555556])



---

## Breast Cancer Survival Prediction


```python
import pandas as pd
```


```python
d = pd.read_csv('C:/Users/Gulfam/Downloads/Compressed/BRCA.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Patient_ID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Protein1</th>
      <th>Protein2</th>
      <th>Protein3</th>
      <th>Protein4</th>
      <th>Tumour_Stage</th>
      <th>Histology</th>
      <th>ER status</th>
      <th>PR status</th>
      <th>HER2 status</th>
      <th>Surgery_type</th>
      <th>Date_of_Surgery</th>
      <th>Date_of_Last_Visit</th>
      <th>Patient_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>TCGA-D8-A1XD</td>
      <td>36.0</td>
      <td>FEMALE</td>
      <td>0.080353</td>
      <td>0.42638</td>
      <td>0.54715</td>
      <td>0.273680</td>
      <td>III</td>
      <td>Infiltrating Ductal Carcinoma</td>
      <td>Positive</td>
      <td>Positive</td>
      <td>Negative</td>
      <td>Modified Radical Mastectomy</td>
      <td>15-Jan-17</td>
      <td>19-Jun-17</td>
      <td>Alive</td>
    </tr>
    <tr>
      <th>1</th>
      <td>TCGA-EW-A1OX</td>
      <td>43.0</td>
      <td>FEMALE</td>
      <td>-0.420320</td>
      <td>0.57807</td>
      <td>0.61447</td>
      <td>-0.031505</td>
      <td>II</td>
      <td>Mucinous Carcinoma</td>
      <td>Positive</td>
      <td>Positive</td>
      <td>Negative</td>
      <td>Lumpectomy</td>
      <td>26-Apr-17</td>
      <td>09-Nov-18</td>
      <td>Dead</td>
    </tr>
    <tr>
      <th>2</th>
      <td>TCGA-A8-A079</td>
      <td>69.0</td>
      <td>FEMALE</td>
      <td>0.213980</td>
      <td>1.31140</td>
      <td>-0.32747</td>
      <td>-0.234260</td>
      <td>III</td>
      <td>Infiltrating Ductal Carcinoma</td>
      <td>Positive</td>
      <td>Positive</td>
      <td>Negative</td>
      <td>Other</td>
      <td>08-Sep-17</td>
      <td>09-Jun-18</td>
      <td>Alive</td>
    </tr>
    <tr>
      <th>3</th>
      <td>TCGA-D8-A1XR</td>
      <td>56.0</td>
      <td>FEMALE</td>
      <td>0.345090</td>
      <td>-0.21147</td>
      <td>-0.19304</td>
      <td>0.124270</td>
      <td>II</td>
      <td>Infiltrating Ductal Carcinoma</td>
      <td>Positive</td>
      <td>Positive</td>
      <td>Negative</td>
      <td>Modified Radical Mastectomy</td>
      <td>25-Jan-17</td>
      <td>12-Jul-17</td>
      <td>Alive</td>
    </tr>
    <tr>
      <th>4</th>
      <td>TCGA-BH-A0BF</td>
      <td>56.0</td>
      <td>FEMALE</td>
      <td>0.221550</td>
      <td>1.90680</td>
      <td>0.52045</td>
      <td>-0.311990</td>
      <td>II</td>
      <td>Infiltrating Ductal Carcinoma</td>
      <td>Positive</td>
      <td>Positive</td>
      <td>Negative</td>
      <td>Other</td>
      <td>06-May-17</td>
      <td>27-Jun-19</td>
      <td>Dead</td>
    </tr>
  </tbody>
</table>
</div>




```python
d = d.dropna()
```


```python
d.isnull().sum()
```




    Patient_ID            0
    Age                   0
    Gender                0
    Protein1              0
    Protein2              0
    Protein3              0
    Protein4              0
    Tumour_Stage          0
    Histology             0
    ER status             0
    PR status             0
    HER2 status           0
    Surgery_type          0
    Date_of_Surgery       0
    Date_of_Last_Visit    0
    Patient_Status        0
    dtype: int64




```python
d0 = d.drop(['Patient_ID','Date_of_Surgery','Date_of_Last_Visit'], axis=1)
```


```python
d = pd.get_dummies(d0, drop_first=True)
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Protein1</th>
      <th>Protein2</th>
      <th>Protein3</th>
      <th>Protein4</th>
      <th>Gender_MALE</th>
      <th>Tumour_Stage_II</th>
      <th>Tumour_Stage_III</th>
      <th>Histology_Infiltrating Lobular Carcinoma</th>
      <th>Histology_Mucinous Carcinoma</th>
      <th>HER2 status_Positive</th>
      <th>Surgery_type_Modified Radical Mastectomy</th>
      <th>Surgery_type_Other</th>
      <th>Surgery_type_Simple Mastectomy</th>
      <th>Patient_Status_Dead</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>36.0</td>
      <td>0.080353</td>
      <td>0.42638</td>
      <td>0.54715</td>
      <td>0.273680</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>43.0</td>
      <td>-0.420320</td>
      <td>0.57807</td>
      <td>0.61447</td>
      <td>-0.031505</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69.0</td>
      <td>0.213980</td>
      <td>1.31140</td>
      <td>-0.32747</td>
      <td>-0.234260</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>56.0</td>
      <td>0.345090</td>
      <td>-0.21147</td>
      <td>-0.19304</td>
      <td>0.124270</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56.0</td>
      <td>0.221550</td>
      <td>1.90680</td>
      <td>0.52045</td>
      <td>-0.311990</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.shape
```




    (317, 15)




```python
X = d.drop(['Patient_Status_Dead'], axis=1)
```


```python
y = d.Patient_Status_Dead
```


```python
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
```


```python
from sklearn.model_selection import cross_val_score
```


```python
cross_val_score(LogisticRegression(), X, y, cv=5).mean()
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\linear_model\_logistic.py:814: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    




    0.8012896825396825




```python
cross_val_score(DecisionTreeClassifier(), X, y, cv=5).mean()
```




    0.6811507936507937




```python
cross_val_score(RandomForestClassifier(), X, y, cv=5).mean()
```




    0.8012896825396825




```python
cross_val_score(SVC(), X, y, cv=5).mean()
```




    0.8044642857142856




```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=1)
```


```python

```


```python
model = SVC()
```


```python
kernel = ['linear', 'poly', 'rbf', 'sigmoid']
scores = []

for i in kernel:
    model = SVC( kernel=i,
    
    gamma='auto')
    model.fit(X_train, y_train)
    scores.append(model.score(X_test, y_test))

```


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_8452/4253783419.py in <module>
          6 
          7     gamma='auto')
    ----> 8     model.fit(X_train, y_train)
          9     scores.append(model.score(X_test, y_test))
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\svm\_base.py in fit(self, X, y, sample_weight)
        253 
        254         seed = rnd.randint(np.iinfo("i").max)
    --> 255         fit(X, y, sample_weight, solver_type, kernel, random_seed=seed)
        256         # see comment on the other call to np.iinfo in this file
        257 
    

    ~\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\svm\_base.py in _dense_fit(self, X, y, sample_weight, solver_type, kernel, random_seed)
        313             self._probB,
        314             self.fit_status_,
    --> 315         ) = libsvm.fit(
        316             X,
        317             y,
    

    KeyboardInterrupt: 



```python
scores
```


```python
svm = SVC(kernel='rbf', gamma='auto')
```


```python
svm.fit(X_train, y_train)
```




    SVC(gamma='auto')




```python
svm.score(X_test, y_test)
```




    0.78125




```python
X_pred = [36.0,0.080353,0.42638,0.54715,0.273680,0,0,1,0,0,0,1,0,0]
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Protein1</th>
      <th>Protein2</th>
      <th>Protein3</th>
      <th>Protein4</th>
      <th>Gender_MALE</th>
      <th>Tumour_Stage_II</th>
      <th>Tumour_Stage_III</th>
      <th>Histology_Infiltrating Lobular Carcinoma</th>
      <th>Histology_Mucinous Carcinoma</th>
      <th>HER2 status_Positive</th>
      <th>Surgery_type_Modified Radical Mastectomy</th>
      <th>Surgery_type_Other</th>
      <th>Surgery_type_Simple Mastectomy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>36.0</td>
      <td>0.080353</td>
      <td>0.42638</td>
      <td>0.54715</td>
      <td>0.273680</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>43.0</td>
      <td>-0.420320</td>
      <td>0.57807</td>
      <td>0.61447</td>
      <td>-0.031505</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69.0</td>
      <td>0.213980</td>
      <td>1.31140</td>
      <td>-0.32747</td>
      <td>-0.234260</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>56.0</td>
      <td>0.345090</td>
      <td>-0.21147</td>
      <td>-0.19304</td>
      <td>0.124270</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56.0</td>
      <td>0.221550</td>
      <td>1.90680</td>
      <td>0.52045</td>
      <td>-0.311990</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_pred = svm.predict([X_pred])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but SVC was fitted with feature names
      warnings.warn(
    


```python
y_pred
```




    array([0], dtype=uint8)



---

## Future sales prediction


```python
import pandas as pd
```


```python
d = pd.read_csv('https://raw.githubusercontent.com/amankharwal/Website-data/master/advertising.csv')
```


```python
d.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TV</th>
      <th>Radio</th>
      <th>Newspaper</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>230.1</td>
      <td>37.8</td>
      <td>69.2</td>
      <td>22.1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>44.5</td>
      <td>39.3</td>
      <td>45.1</td>
      <td>10.4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17.2</td>
      <td>45.9</td>
      <td>69.3</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>151.5</td>
      <td>41.3</td>
      <td>58.5</td>
      <td>16.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>180.8</td>
      <td>10.8</td>
      <td>58.4</td>
      <td>17.9</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.isnull().sum()
```




    TV           0
    Radio        0
    Newspaper    0
    Sales        0
    dtype: int64




```python
d.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 4 columns):
     #   Column     Non-Null Count  Dtype  
    ---  ------     --------------  -----  
     0   TV         200 non-null    float64
     1   Radio      200 non-null    float64
     2   Newspaper  200 non-null    float64
     3   Sales      200 non-null    float64
    dtypes: float64(4)
    memory usage: 6.4 KB
    


```python
import seaborn as sns
```


```python
sns.scatterplot(d.TV , d.Sales, color='red')
sns.scatterplot(d.Radio , d.Sales, color='blue')
sns.scatterplot(d.Newspaper , d.Sales, color='green')

```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='TV', ylabel='Sales'>




    
![png](output_715_2.png)
    



```python

```


```python

```


```python
X = d.drop(['Sales'], axis=1)
```


```python
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TV</th>
      <th>Radio</th>
      <th>Newspaper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>230.1</td>
      <td>37.8</td>
      <td>69.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>44.5</td>
      <td>39.3</td>
      <td>45.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17.2</td>
      <td>45.9</td>
      <td>69.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>151.5</td>
      <td>41.3</td>
      <td>58.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>180.8</td>
      <td>10.8</td>
      <td>58.4</td>
    </tr>
  </tbody>
</table>
</div>




```python
y = d.Sales
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=1)
```


```python
from sklearn.linear_model import LinearRegression
```


```python
model = LinearRegression()
```


```python
model.fit(X_train, y_train)
```




    LinearRegression()




```python
model.score(X_test, y_test)
```




    0.8747226291661846




```python
model.predict([[17.2,45.9,69.3]])
```

    C:\Users\Gulfam\AppData\Local\Programs\Python\Python310\lib\site-packages\sklearn\base.py:450: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
      warnings.warn(
    




    array([10.25415824])



---


```python

```


```python

```


```python

```


```python

```
